# CIQ – gemeinsamer IR-Operator, Planck-Schwingung, Spektrallinien und 2D/3D-Geometrie

**Revisionsdatum:** 10. November 2026  
**Status:** analytischer und numerischer Audit ohne Daten-Fit; Dokumentation einer Forschungsfrage, kein experimenteller Nachweis einer zusätzlichen gravitativen IR-Kopplung.  
**Leitfrage:** Ist die Verknüpfung von Spektrallinien, `c`, Planck-Länge/-Zeit und einer gemeinsamen IR-Referenz schon bekannt? Was davon geht über bekannte Gleichungen hinaus und könnte eine neue, falsifizierbare Hypothese sein?

## 0. Forschungslogik und Entwicklungsfolge: Ursprünge NICHT überschreiben

Der Ausgangspunkt des Nutzers wird in dieser Reihenfolge erhalten:

1. **Ursache:** Bei der Entstehung eines Energiepakets/Photons ist eine Schwingung mit Energie verknüpft.
2. **Planck-Kalibrierung:** Länge und Zeit sind gekoppelt, denn `ell_P/t_P = c`. Ein Wellenzug hat eine dimensionslose gemeinsame Skalenzahl.
3. **Relativbewegung:** Annäherung zur Ursache staucht empfangene Wellenlänge und Periode gemeinsam; Entfernung dehnt beide gemeinsam. Die empfangene Energie ändert sich invers.
4. **Ein gemeinsamer IR-Referenzoperator:** 10 µm wird als reproduzierbarer Startwert verwendet; der Operator vergleicht zwei Beobachtungen derselben Spektrallinie.
5. **Sinus/Cosinus-Geometrie:** `sin(2πx/λ)` wird der Längenachse und `cos(2πt/T)` der Zeitachse zugeordnet (oder vertauscht). Das wird gegen eine physikalische elektromagnetische Welle geprüft.
6. **2D-/3D-Oberfläche, Entropie und Gravitation:** Die 2D-Kontrast-/Ising-Grenzstruktur soll mit einer räumlichen 3D-Feldantwort verglichen werden, eventuell im IR-Bereich und schließlich mit `G`.
7. **Frühere Negativbefunde bleiben:** Die direkte Ising-Higgs-Brücke scheiterte im hochgeladenen EW-Audit; die unveränderte Originaldatei liegt unter `quellen_originale/`.

**Trennung:** Eine Gleichung kann exakt sein, ohne den vermuteten physikalischen Mechanismus zu belegen. Die chronologische Kette dient dazu, eine neue Prüfung aus dem ursprünglichen Gedanken sichtbar abzuleiten, nicht alte Fehlschlüsse rückwirkend zu löschen.

## 1. Was in der Fachliteratur längst zusammengebracht wurde

Die Planck-Einheiten wurden Ende des 19. Jahrhunderts aus `G`, `c`, `h` formuliert. Das Standardverhältnis `ell_P/t_P=c` und der Vergleich der Quantenskala `h c/λ` mit gravitativen Größen sind bekannte Methoden. Fermilab Holometer FAQ zeigt ausdrücklich die Photonenwellenlänge und den Schwarzschildradius gemeinsam im Planck-Diagramm. In der Relativitätstheorie ist die gemessene Lichtfrequenz `ω=-k_μu^μ` ein etablierter Beobachtervergleich, einschließlich gravitativer Rotverschiebung.

**Damit sind die algebraischen Einzelbeziehungen nicht neu:**

```
ell_P = sqrt(hbar*G/c^3)
t_P   = sqrt(hbar*G/c^5)
nu    = c/lambda
T     = 1/nu
E     = h*nu
N     = lambda/ell_P = T/t_P = h*c/(E*ell_P) = 2*pi*E_P/E
E_P   = hbar/t_P
```

Die **spezifische Arbeitsfolge** des CIQ-Projekts – 10-µm-IR-Anker, getrennte Sinus(Länge)-Cosinus(Zeit)-Zuordnung, Oberflächenkontrast/Ising, 2D-Quadrupol, 3D-Ausbreitung und Suche nach einer unabhängig bestimmten gravitativen Kopplung – lässt sich als kombinierter **Forschungsansatz** dokumentieren. Eine gesicherte Veröffentlichung mit exakt derselben Kombination wurde im begrenzten Quellenabgleich nicht festgestellt. Daraus folgt **kein Prioritäts- oder Neuheitsbeweis**. Vor allem existiert noch kein neuer mathematischer Operator mit nachgewiesener Wirkung, der über den bekannten Rotverschiebungsfaktor hinausgeht.

Externe Kontrollquellen (URLs, Stand dieser Recherche):

- Max-Planck-Einheiten: https://link.springer.com/article/10.12942/lrr-2013-2
- Fermilab Holometer FAQ, Zusammenhang Photonenergie/Schwarzschildradius/Planck: https://holometer.fnal.gov/faq.html
- Stanford Encyclopedia of Philosophy – Quantum Gravity: https://plato.stanford.edu/entries/quantum-gravity/
- CODATA-Referenztabelle: https://pmc.ncbi.nlm.nih.gov/articles/PMC9888147/
- Gravitative Photonenfrequenz `-k·u`, Lehrskript (S. 4.42): https://members.ift.uam-csic.es/jfbarbon/Teaching_files/AG12.pdf

## 2. Der *gleiche* IR-Operator – nicht heimlich austauschen

Die frühere, durch das Projekt vorgegebene Definition bleibt **unverändert**:

\[
K_{\mathrm{IR}}(A\to B)
=\frac{\lambda_B}{\lambda_A}
=\frac{T_B}{T_A}
=\frac{E_A}{E_B}
=\frac{\nu_A}{\nu_B}.
\]

Hier sind A (Emission/Ursache) und B (Empfang/Beobachter) konkret definiert. Eine bloße Referenzwellenlänge ist **kein Ruhesystem**. Im flachen Raum und bei Bewegung entlang des Strahls gilt für positiv = entfernen:

\[
K_{\mathrm{IR}}(\beta)=\sqrt{\frac{1+\beta}{1-\beta}},\quad \beta=v/c.
\]

Im gekrümmten Raum gilt für den auf dem Nullstrahl transportierten Wellenvektor `k_μ` und die jeweilige Beobachter-Vierergeschwindigkeit `u`:

\[
\frac{\nu_B}{\nu_A}=\frac{(-k_\mu u^\mu)_B}{(-k_\mu u^\mu)_A},\quad K_{\mathrm{IR}}=\frac{\nu_A}{\nu_B}.
\]

Die 10-µm-Referenz **kalibriert eine konkrete ausgesandte Welle**, sie legt den Faktor K nicht unabhängig von Bewegung und Geometrie fest. Wenn die Quelle mehrere Linien emittiert, gilt bei gleicher Strecke und in der geometrischen Optik im Vakuum für alle derselbe relative Verschiebungsfaktor. Diese universelle Relativität ist der Nulltest eines speziellen IR-Operators, kein eigenständiger Nachweis einer IR-Sonderkopplung.

### Zahlenreferenz

Bei `lambda_A = 10 µm`:

- Frequenz `29,9792458 THz`;
- Periode `33,35640952 fs`;
- Energie `0,1239841984 eV`;
- Planck-Zahl `N ≈ 6,1871424×10²⁹`;
- bei Annäherung mit `0,6c`: `K=0,5`, λ=5 µm, T halbiert, E verdoppelt;
- bei Entfernung mit `0,6c`: `K=2`, λ=20 µm, T verdoppelt, E halbiert.

Im gesamten Frequenzspektrum bleibt `lambda f = c` und `lambda/ell_P = T/t_P` erhalten. Dies ist eine Einheitendarstellung plus etablierte Wellen- und Relativitätsphysik, **kein Nachweis dafür, dass Photonen aus diskreten Planck-Schritten bestehen.**

## 3. 2D-Sinus(Länge)/Cosinus(Zeit) und Doppelwinkel: Prüfung

Im gewählten Phasenmodell:

\[
\phi_x=2\pi x/\lambda=2\pi(x/\ell_P)/N,\quad
\phi_t=2\pi t/T=2\pi(t/t_P)/N,
\]
\[
S_x=\sin\phi_x,\quad C_t=\cos\phi_t.
\]

Für die Lichtfront `x=ct` gilt `phi_x=phi_t`; also behalten die getrennten Sinus- und Cosinusausdrücke einen Quadraturabstand von `π/2=90°`. Die **physikalische einzelne ebene Welle** hat dagegen eine gemeinsame Phase `phi=phi_t-phi_x`, die entlang einer Lichtfront konstant ist. Werden Raum- und Zeitargument frei und unabhängig variiert, ist die Quadratur nicht allgemein konstant.

Unabhängig davon sei ein zweidimensionaler Richtungsvektor `u=(cos θ, sin θ)` definiert. Der spurfrei-quadratische Tensor besitzt die beiden Komponenten:

\[
Q_{xx}=u_x^2-u_y^2=\cos(2\theta),\quad
Q_{xy}=2u_xu_y=\sin(2\theta).
\]

Mathematisch exakt: eine räumliche 90°-Drehung wechselt beide Vorzeichen, eine 180°-Drehung stellt sie wieder her. Das erinnert an die Winkeltransformation transversaler Spin-2-Gravitationswellen, **ist aber kein Beweis für ein Gravitationsfeld oder einen Spin-2-Erzeugungsmechanismus**. Elektromagnetische Wellen laufen in allen Spektralbereichen im 3D-Raum; eine räumliche 2D-Projektion ist kein Funk-zu-Licht-Dimensionsübergang.

## 4. Der harte Test: Lässt sich G ohne Vorannahme aus N bestimmen?

**Nein, aus diesen Beziehungen allein nicht.** Da `ell_P=sqrt(hbar G/c³)` und `t_P=ell_P/c`, steckt G bereits in der angegebenen Planck-Skala. Als Gegenprobe setze `G_neu=4G`. Dann:

```
ell_P,neu = 2 ell_P
t_P,neu   = 2 t_P
ell_P,neu/t_P,neu = c
N_neu (gleiche Spektrallinie) = N/2
```

Die Spektralgleichungen gelten also auch mit einem anderen G. Der Zahlenwert von G wird **nicht** durch `c=ell_P/t_P` oder durch die Planck-zu-Spektrum-Proportion bestimmt.

Die dimensionslose Gravitationskopplung eines Protons `alpha_G=G*m_p²/(hbar c)` ist ein geeigneter Prüfwert. Aber der Messwert G muss aus einer anderen Beobachtungsgröße kommen (Gravitation, Geometrie, dynamischer Tensor), nicht aus derselben Definitionsgleichung rückwärts herausgelesen werden.

Als **Kontrollrechnung mit vorgegebenem G** wird eine gravitative Spektralverschiebung erzeugt und anschließend wieder invertiert:

```
M = 1.98847×10^30 kg
r_A = 100 km
r_B = 200 km
q = nu_B/nu_A = sqrt[(1-2GM/(c²r_A))/(1-2GM/(c²r_B))]
K_IR = 1/q ≈ 1.0075793167
```

Daraus kann G algebraisch rekonstruiert werden, **weil es vorher eingesetzt wurde**. In einem wirklichen Experiment müssen M und Radien sowie die Bewegung unabhängig gemessen werden, sonst erhält man höchstens die Kombination `GM`.

## 5. IR-Sonderrolle, Oberflächenthermik und früher EW-Negativtest

- Für ideale Schwarzkörper hängt das IR-Maximum über das Wiensche Gesetz von der Temperatur ab; 10 µm ist z.B. nahe dem Maximum von 290 K. Die Temperatur/Emissivität ist keine universelle Kernkonstante.
- Eine Oberfläche kann Energie und Entropie tragen. Die zugehörige gravitative Quelle wird über den **vollständigen Energie-Impuls-Tensor** beschrieben. Die Oberfläche eines Atomkerns ist nicht die thermische Haut eines 300-K-Körpers und nicht der Horizont eines Schwarzen Lochs.
- Im EW-Ising-Audit auf Seite 1 lagen für die damalige Parametrisierung z.B. `m_W(CIQ)=74,044 GeV` gegenüber `80,369 GeV` Referenz; die damalige direkte Ising-Higgs-Brücke ist kein bestandener Masse-Nachweis. Alte PDF **unverändert** beigefügt.
- Vor dem Übertrag ist zu prüfen, ob die alte Ising-Randdimension ~1,754 für den benutzten konkreten Randtyp passend ist. Der im Bericht angegebene 7/4-Referenzwert darf nicht ungeprüft auf jede Ising-Spincluster-Oberfläche übertragen werden.
- Das dimensionslose `k=10^-4` aus einem früheren IR-Kontrastmodell ist **ohne konkrete physikalische Umrechnung keine Wellenlänge von 10 µm**.

Aus dem aktuell einzigen eindeutig formulierten gemeinsamen Operator `K_IR` erhält man **keine zusätzliche Oberflächen-IR-Gravitationskopplung**. Dafür fehlen ein neues dimensionsrichtiges Gesetz bzw. ein kovarianter konservierter Zusatz-Tensor samt Vorhersagen. Man darf diese fehlende Gleichung nicht durch das freie Einstellen eines Faktors zu G ersetzen.

## 6. Reale Falsifikationsprobe für den vermuteten gemeinsamen neuen IR-Operator

1. **Vorregistrierte Quelle:** Emissionsereignis, Spektrallinien einschließlich einer IR-Linie und mindestens einer optischen/radiofrequenten Kontrolllinie, bekannte lokale Quellbewegung.
2. **Geometrie/Empfänger:** Beobachterbahn, bekannte Massen, Abstände, gravitative Potentiale, Instrumentenvergleich; Messung der Frequenzverhältnisse.
3. **Nullmodell:** `K_GR` aus etabliertem Doppler + gravitativer Redshift entlang gleicher Strecke. Keine nachträgliche Anpassung pro Linie.
4. **Residuum:** `R(λ) = [nu_B(λ)/nu_A(λ)] / [nu_B/nu_A]_GR - 1`.
5. **Behauptete IR-Sonderwirkung:** Damit ein physikalisch neuer Operator vorliegt, muss die alte Kontrast-Oberflächendynamik **vorher** die Form und Stärke von `R(λ)` ohne freien Nachfit für mehrere Kernarten bzw. Frequenzen festlegen.
6. **Gravitativer Schluss:** Ein reproduzierbares Residuum müsste gegen instrumentelle Dispersion, Plasma, Material- und Temperaturverschiebung, Linienform, Kern-QED, Photonenstrahlung und alternative Standardquellen bestehen. Für G ist unabhängig bestimmte Masse oder ein eigenständiger, vollständig spezifizierter Einsteintensor notwendig.

**Bestandener Audit:** Die vorliegenden Rechenregeln und eine Winkel-Tensor-Konstruktion sind reproduzierbar. **Offen:** Eine physikalische IR-spezifische Kopplung, die ohne G als Eingabe `G` erzeugt oder die Teilchenmasse erklärt, wurde nicht bestimmt.

## 7. Reproduzierbarkeit

Vom Archiv-Hauptordner:

```
python3 code/ir_operator_pruefung.py
```

Der Code erzeugt die CSV-Dateien in `results/` und `audit_results.json`; es werden keine zusätzlichen Python-Pakete, Netzverbindungen oder Fittingverfahren benötigt. Interne Rechenchecks (aktuell 62/62) prüfen vorgegebene mathematische Identitäten und toy-model Bedingungen, **keine 62 empirischen Nachweise**. Dateien in `quellen_originale/` sind unverändert kopiert und werden im SHA256-Manifest nachgewiesen.

## 8. Kurzfazit zur Frage „Hat man das so wie wir verbunden?“

**Ja**, die Planck-Verknüpfung von Licht, Frequenz, Wellenlänge und Zeit sowie gravitative Frequenzvergleiche sind seit langem Teil der Physik. **Die konkrete CIQ-Forschungssequenz** aus einem IR-Referenzoperator und dem 2D-/3D-Oberflächenkontrast ist als *kombinierter Ansatz* weiter testbar; sie ist aber noch **keine unabhängig hergeleitete Naturkonstante oder nachgewiesene neue Wirkung**. Der nächste wissenschaftlich entscheidende Schritt ist die von der 10-µm-Referenz unabhängige quantitative Oberflächen-/Gravitationsvorhersage.
