# CIQ - IR-Referenz, Planck-Schwingung, Bezugssystem und Lichtgravitation

**Datum:** 10. November 2026  
**Status:** Reproduzierbarer algebraischer und lokaler Relativitäts-/Tensor-Audit, kein Fit; keine experimentelle Bestätigung einer neuen Raumzeitdynamik.  
**Ziel:** Originale Entstehungsfolge des Gedankens bewahren und ihre Rechenfolgen samt Nulltests trennen.

## A. Ursprünglicher Gedanke - unverändert in der Prüfstruktur

1. Die Ursache ist ein Entstehungsereignis, bei dem ein Photon als Energiepaket mit Schwingung entsteht.
2. Die Schwingung ist gemeinsam mit Länge und Zeit an die Planck-Skala gekoppelt; Licht ist in Planck-Einheiten mit `l_P/t_P = c` beschrieben.
3. Bewegung auf die Ursache zu staucht die **gesamte gemessene Schwingungsskala** (Länge und Periode); Bewegung von ihr weg dehnt sie.
4. `c` bleibt lokal konstant; die Energie gehört zur Schwingung und ist deshalb ebenfalls mit der Skala gekoppelt.
5. Licht trägt selbst Energie und gravitiert. Die Vergleichsrechnung muss Quelle, Beobachter und Raumzeitweg explizit nennen.
6. **Nachträgliche Präzisierung:** Die Startkalibrierung soll im **Infrarotbereich** liegen. Dafür verwenden wir als erste konkrete Referenz 10 µm, zusätzlich 1 und 100 µm als Blindkontrollen.

Die Punkte sind als **Modellverständnis/Prüfauftrag** dokumentiert, nicht bereits als vollständige Herleitung der Raumzeitkrümmung. Die Anpassung vom früheren 500-nm-Beispiel zur IR-Referenz wird nicht rückwirkend verschleiert: Die älteren Codes bleiben im Archiv vorhanden, während der neue IR-Code die Präzisierung explizit umsetzt.

## B. Festgelegtes Messprotokoll

- Ursache A: Quelle emittiert im eigenen lokalen Ruhesystem einen Photonenzustand mit Referenzwellenlänge `lambda_A=10 µm`; dort gelten `E_A=h c/lambda_A` und `T_A=lambda_A/c`.
- Photon: im lokalen Modell Ausbreitung nach +x; dimensionsloser Nullwellenvektor `k^mu=(1,1,0,0)`.
- Beobachter B: Geschwindigkeitskomponente `beta=v/c` entlang +x relativ zur Quelle. `beta=-0,6` bedeutet Annäherung; `beta=+0,6` Entfernung.
- Raumzeit: zunächst Minkowski; unabhängig davon eine **vorgegebene** Schwarzschild-Außenmetrik für einen rein illustrativen Gravitationsrotverschiebungs-Test.
- Kalibration: `l_P=sqrt(hbar G/c^3)`, `t_P=sqrt(hbar G/c^5)`, `E_P=hbar/t_P`; `G=6,67430e-11` (nominaler CODATA-Wert mit Messunsicherheit); `c` und `h` SI-exakt.
- **Keine Parameteranpassung** an die Endwerte. 10 µm ist ein Messankerpunktszenario, nicht ein aus CIQ hergeleiteter Naturwert.

## C. Koppelrechnung

Es gelten

```
lambda_A / l_P = T_A / t_P = N_A
E_A = h / T_A = h c / lambda_A = 2 pi E_P / N_A
```

Der allgemeine Beobachtervergleich entlang der Lichtbahn lautet für Quelle A und Beobachter B

```
D_AB = f_B/f_A = (- k_mu u_B^mu)/(- k_mu u_A^mu)
K_AB = 1/D_AB
lambda_B = K_AB lambda_A
T_B = K_AB T_A
E_B = E_A/K_AB
```

`u_A` und `u_B` sind die normierten lokalen Vierergeschwindigkeiten. In einer gekrümmten Raumzeit ist der Wellenvektor entlang der Lichtbahn zu transportieren. In der vorliegenden flachen, radialen Referenz ergibt sich `D=gamma*(1-beta)` und `K=sqrt((1+beta)/(1-beta))`.

**Bemerkung:** Das INFRAROT legt `lambda_A` und damit `E_A`, `T_A`, `N_A` fest. Es legt allein weder die Vierergeschwindigkeiten fest, noch definiert es ein bevorzugtes physikalisches Ruhesystem.

### C1. Zahlen für 10 µm

| Größe | Ursache und Ruhe | B nähert sich mit 0,6c | B entfernt sich mit 0,6c |
|---|---:|---:|---:|
| `K` | 1 | 0,5 | 2 |
| `lambda` | 10 µm | 5 µm | 20 µm |
| `T` | 33,35640952 fs | 16,67820476 fs | 66,71281904 fs |
| `E` | 0,1239841984 eV | 0,2479683969 eV | 0,0619920992 eV |
| `N=lambda/l_P=T/t_P` | 6,1871424e29 | 3,0935712e29 | 1,2374285e30 |
| `lambda/T` | c | c | c |

Die drei Werte entstehen aus einem **identischen ausgehenden Photon** in verschiedenen Beobachter-Bezugssystemen. Sie sind keine Erzeugung zusätzlicher Energie bei der Bewegung; die im jeweiligen System gemessene Energie ist anders.

### C2. IR-Blindkontrollen

Bei 1, 10 und 100 µm liefern dieselben Bewegungen jeweils dieselben **relativen** `K`-Werte 0,5 / 1 / 2. Die absoluten Photonenergien und `N`-Werte unterscheiden sich um Faktoren 10. Daraus folgt: Das Infrarot ist ein gültiger Startanker, aber die Verschiebung `K` ist nicht **durch den IR-Bereich allein** bestimmt.

## D. Gekrümmte Raumzeit als unabhängiger Test

Wir geben eine Schwarzschild-Außenmetrik ausdrücklich vor, um *geometrische* Gravitationsrotverschiebung separat von Bewegung zu rechnen:

```
Quelle A statisch bei r_A=4 r_s
Empfänger B statisch bei r_B=8 r_s
f_B/f_A = sqrt[(1-r_s/r_A)/(1-r_s/r_B)] = sqrt(6/7)
K_grav = sqrt(7/6) = 1,08012344973464
```

Ein ursprüngliches 10-µm-Photon wird dort als 10,8012345 µm empfangen, auch wenn Quelle und Empfänger gegenüber ihrer jeweiligen statischen Beobachterfamilie **nicht radial bewegt** sind. Das zeigt: Der Beobachtervergleich enthält einen echten geometrischen Effekt zusätzlich zur Bewegung.

Falls B am Empfangsort *zusätzlich* mit `+0,6c` radial nach außen bewegt ist, wird die Frequenz nochmals lokal halbiert. Daraus ergibt sich `K_gesamt=2,16024689947`; bei 10 µm aus der Quelle wären es ca. 21,602469 µm am Empfänger. Dieser Multiplikationsvergleich verwendet eine vorgegebene Metrik und ist **keine Berechnung der Raumzeitkrümmung aus der Photonenergie**.

## E. Licht als Quelle der Raumzeitkrümmung

Die Einstein-Gleichung lautet:

```
G_{mu nu} = (8 pi G/c^4) T_{mu nu}
```

Elektromagnetische Energie und Impuls tragen zu `T_{mu nu}` bei. Für einen **klassischen idealisierten Nullstrahl** kann lokal geschrieben werden:

```
T^{mu nu} = u_0 k^mu k^nu ,  k_mu k^mu = 0
```

Mit dem normierten Quellrahmen `u_0=1 J/m³` als rein numerischem Anschauungswert ergibt sich für einen Beobachter `u_B/u_A = D^2`. Beim Annähern mit 0,6c ist `D=2`, die gemessene Strahlungsenergiedichte also viermal so groß; bei Entfernen ist sie ein Viertel.

Ein algebraischer (nicht vollständig integrierter) lokaler Quellenvergleich mit spurfreiem `T` liefert für die gemessene Ricci-Komponente:

```
R_(0)(0) = 8 pi G * u_beobachtet / c^4
             = 2,0766474428e-43 m^-2 bei u_0=1 J/m³ im Quellrahmen.
```

Diese Komponenten ändern sich zwischen Beobachtern, **ohne dass dadurch eine zweite, neue Raumzeit erzeugt werden muss**. Die Krümmung wird durch die physikalische Feldkonfiguration bestimmt; Koordinaten-/Rahmenprojektionen verändern ihre numerischen Komponenten.

**Grenze:** Die Photonwellenlänge allein bestimmt weder Strahlungsenergiedichte noch Querschnitt, Pulsform, Polarisation, Randbedingungen oder eine eindeutige Raumzeitmetrik. Ein einzelnes Photon kann nicht als klassisches homogenes Nullfluid mit bekanntem Volumen behandelt werden. Die metrische Rückwirkung und mögliche Messsignale einer IR-Strahlung erfordern einen spezifizierten Energie-Impuls-Tensor samt Feld-/Randbedingungen und eine Einstein-Maxwell- oder geeignet quantisierte Rechnung.

## F. Harte Negativtests

**F1: Frequenzverschiebung ist nicht globale Längenkontraktion.** Bei `beta=-0,6` gilt Doppler-`K=0,5`, aber ein bewegter materieller Stab ist in Bewegungsrichtung nur um `1/gamma=0,8` kontrahiert, quer bleibt seine Länge 1. Eine universelle Stauchung **des Raums** um `0,5` folgt nicht aus der Photonwelle.

**F2: Fundamental Planck-Länge/-Zeit.** Das gemeinsam mit `K` gestauchte bzw. gedehnte `N` gehört zur gemessenen Photonenschwingung. Für unveränderte `hbar`, `G`, `c` bleiben `l_P`, `t_P` unverändert. Wenn man entgegen dieser Annahme `l'_P=K l_P`, `t'_P=K t_P` als fundamentale Maße bei konstantem `hbar`, `c` verlangt, müsste `G'=K²G` sein. Das ist ein zusätzlicher, empirisch nicht belegter Ansatz (und wäre noch kein vollständiges konsistentes Modell).

**F3: IR als Bezugsanker vs. Bezugssystem.** 10 µm ist eine spektrale Kalibrierung. Ein physikalisches Bezugssystem braucht auch Quellen- und Empfängerbewegung (z.B. `u_A`, `u_B`) und die Geometrie entlang des Lichtweges. Photonen haben selbst kein Ruhesystem.

**F4: Null-Geometrie-Kontrolle.** Ohne vorgegebene Krümmung und ohne Einsetzen eines `T_munu` in eine gelöste Einstein-Gleichung liefert die `K`-Gleichung keine eigenständige Metrik-/Krümmungsvorhersage. Für ein echtes neues CIQ-Signal ist eine berechenbare Abweichung von Standard-Doppler und Standard-Gravitationsrotverschiebung erforderlich.

## G. Bewertungsblatt

| Aussage | Status |
|---|---|
| `l_P/t_P=c` | Mathematisch exakt aus Definition |
| `lambda/l_P = T/t_P`, `E=2pi E_P/N` | Mathematisch exakt für eine Vakuum-Photonenschwingung im lokalen Bezug |
| Gemeinsame Stauchung/Dehnung von beobachteter Wellenlänge und Periode | Bestätigt, sofern Quelle/Empfänger-Bewegung bekannt |
| IR als Ausgangskalibrierung | Rechnerisch möglich, 10 µm ausdrücklich gewählt |
| IR-Wellenlänge allein liefert K | Verneint: K benötigt u_A, u_B, Lichtweg/Geometrie |
| Lichtenergie krümmt Raumzeit | Etablierte Einstein-Gleichung, klassische Feldquelle beschrieben |
| Ein Photon erzeugt dadurch seine eigene Planck-Skalenänderung | Nicht gezeigt |
| Beobachter-K bewirkt globale Dehnung des Raums | Nicht gezeigt; Stab-/Quertest widerspricht universeller Interpretation |
| Vollständige selbstkonsistente Einstein-Maxwell-Lösung im IR | Nicht durchgeführt |

## H. Nachvollziehbarkeit

Von der ZIP-Wurzel aus:

```sh
python3 code/audit.py
python3 code/bezugssystem_und_lichtgravitation.py
python3 code/ir_ursache_raum_audit.py
```

Alle drei Programme verwenden nur die Python-Standardbibliothek. Das erste Script erhält die **ursprüngliche 500-nm-Rechnung**; der zweite Schritt ergänzt Quelle/Beobachter und einen lokalen klassischen Licht-Stresstensor; der dritte Schritt setzt die **nachträglich festgelegte IR-Referenz** (10 µm, 1 und 100 µm Gegenproben) um. CSV-/JSON-Rohresultate stehen unter `results/`. Die internen PASS-Zahlen überprüfen Modellgleichungen und Rechenoperationen, nicht empirische Befunde.

### Quellen (fachlicher Vergleich, keine neue unabhängige CIQ-Bestätigung)

- NIST CODATA 2022: https://physics.nist.gov/cuu/pdf/all.pdf
- NASA Infrarot: https://science.nasa.gov/ems/07_infraredwaves/
- NASA JWST MIRI: https://science.nasa.gov/mission/webb/mid-infrared-instrument-miri/
- Ursprungsdateien (unverändert) unter `quellen/`: `Planck_zip_original.zip`, `Test_Original.pdf`, `Planck_Laenge_Original.pdf`.

## I. Nächste gezielte falsifizierbare Stufe

Eine **einheitliche IR-Kopplung an die Metrik** ist erst dann mehr als eine gemeinsame Umbenennung des Dopplerfaktors, wenn sie eine explizite Zusatzgleichung für die Raumzeit enthält, z.B. eine wohldefinierte lokale Energie-Impuls-Quelle und deren Dynamik. Dann müssen *für identische Quelle, Empfänger und Geometrie* die Vorhersagen mit und ohne Zusatzterm verglichen werden. Die IR-Ankerwellenlänge sollte vor der Rechnung festgelegt bleiben; eine nachträgliche Wahl zur Herstellung des gewünschten K würde den Blindtest verfälschen.
