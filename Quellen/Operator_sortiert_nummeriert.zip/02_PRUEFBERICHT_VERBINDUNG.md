# CIQ – Rückwärtsaudit: IR-Operator, Planck-Grundtakt, Spektrallinien, Phasen-Geometrie und die Konstanten c/G

**Stand 10.11.2026 · nachvollziehbare neue Prüfetappe, kein Fit · CIQ als Analyse- und Vergleichsrahmen.**

## 0. ursprünglicher Gedankengang und erhaltene Fehlergeschichte

Ursprüngliche Idee (als Hypothese erhalten): Die Ursache sendet ein Energiepaket mit einer Schwingung. Die gemessene räumliche und zeitliche Periodendauer sind über Planck-Länge/-Zeit gemeinsam kalibriert. Bewegung des Beobachters ändert den empfangenen Schwingungstakt und die Spektralzuordnung. In der Kontrast-Simulation wird eine 2D-Grenz-/Oberflächenstruktur mit der 3D-Ausbreitung und anschließend der gravitativen Wirkung verbunden. Als gemeinsame IR-Referenz wird weiterhin 10 µm verwendet; die im alten Audit eingeführte Verhältnisgröße `K_IR = lambda_B/lambda_A = T_B/T_A = E_A/E_B` bleibt **unverändert**.

Historische Präzisierungen, ohne Originale zu überschreiben:

1. `l_P/t_P=c` ist eine exakte Konsequenz der Definitionen; es beweist keine diskreten Bewegungsschritte von Photonen.
2. Die gemeinsame Änderung von empfangener Wellenlänge und Periode ist physikalisch real; die fundamentalen Planck-Einheiten ändern sich dabei nicht automatisch.
3. Ein Sinus-/Cosinus-Paar hat 90° Phasenabstand (`π/2`, **nicht** 180°). Eine quadratische 2D-Tensorkonstruktion erzeugt mathematisch `2θ`, aber keine neue Gravitationslösung.
4. Der frühere elektroschwache Ising-Higgs-Test war bei den Referenzparametern negativ. Die damalige Abweichung der W-/Z-Massen bleibt erhalten, statt stillschweigend auf das heutige Modell umetikettiert zu werden.
5. In der älteren Higgs-Audit-Fassung tritt ein Widerspruch zwischen der exakten Bedingung `f_zeta=-f_alpha` (für konstanten VEV) und einer späteren `f_zeta=f_alpha`-Behauptung auf. Dieser Fehler wird nicht übernommen.
6. Eine dimensionslose IR-Wellenzahl `k=10^-4` der Kontrast-Simulation ist **ohne explizite Dimensions- und Skalenfestlegung** keine Wellenlänge von 10 µm.

## 1. Spektrallinie -> Energie -> räumlich/zeitliche Planck-Kopplung

Ein Photon einer lokalen Vakuumwelle besitzt

```
E = h nu,       lambda * nu = c,       T = 1/nu,
l_P = sqrt(hbar * G/c^3),             t_P = l_P/c,
N = lambda/l_P = T/t_P = h*c/(E*l_P) = 2*pi*E_P/E,
E_P = hbar/t_P.
```

Die Gleichheit der beiden dimensionslosen Zähler N ist mathematisch exakt, **für jedes Spektralgebiet**. Die referenzierte Zahl `N` ist keine experimentell nachgewiesene Stückzahl von fundamentalen Raum- oder Zeitabschnitten. Da `l_P` und `t_P` von `G` abhängen, ist N auch keine unmittelbar G-unabhängige Beobachtungszahl.

Bei der unveränderten IR-Referenz `lambda_A = 10 µm`:

- `nu_A = 29,9792458 THz`;
- `T_A = 33,35640952 fs`;
- `E_A = 0,1239841984 eV`;
- `N_A = 6,1871424057e29`;
- `nu_A*t_P = 1,6162550244e-30` Schwingungen pro Planck-Zeit (reelle Verhältniszahl).
- `E_A/c² = 2,2102190943e-37 kg` als Energie-Massenäquivalent des Photons; die **invariante Ruhemasse des Photons ist weiterhin null**.

Eine Änderung eines Atomzustands kann die Masse des gesamten Atoms durch seine Bindungs-/Anregungsenergie verändern. Wird ein Photon abgegeben, müssen auch Impulsrückstoß und die Energiebilanz des restlichen Systems berücksichtigt werden. Nicht jedes IR-Photon ist ein Kernübergang.

## 2. Der gemeinsame IR-Operator bleibt derselbe

Wie im hochgeladenen Originalaudit:

```
K_IR(A->B) := lambda_B/lambda_A = T_B/T_A = E_A/E_B = nu_A/nu_B.
```

Das ist ein Vergleich **derselben** Spektrallinie bei Quelle A und Beobachter B. Die zum Zeichnen des gesamten Spektrums verwendete zusätzliche Referenzzahl `lambda/10µm` ist bloß eine Darstellung und KEIN zweiter physikalischer Wechselwirkungsoperator.

Bei radialer Relativbewegung im flachen Raum:

```
beta = v/c  (positiv: Empfänger bewegt sich von der Quelle weg),
K_IR(beta) = sqrt[(1+beta)/(1-beta)].
```

Bei `beta=-0,6` ist `K=0,5` (IR-Linie 5 µm), bei `beta=0` `K=1` (10 µm), bei `beta=+0,6` `K=2` (20 µm). Das ist das Messprotokoll von Ursache, Signal und Beobachter. Es setzt kein Photon-Ruhesystem voraus.

In einer gegebenen gekrümmten Geometrie gelten die mit Quelle und Beobachter kontrahierten Vierervektoren:

```
nu_B/nu_A = [(-k_mu u^mu)_B]/[(-k_mu u^mu)_A]
K_IR = nu_A/nu_B.
```

Im Allgemeinen sind sowohl Wegtransport als auch Bewegungs-/Gravitationseinfluss enthalten. Nur die Auswahl der IR-Frequenz liefert kein Bezugssystem.

## 3. c aus Spektrallinien: direkte Umkehrung

Misst man Frequenz und Wellenlänge derselben Lichtwelle lokal im Vakuum, so ist `c = lambda*nu` bestimmbar. Für die 10-µm-Referenz `1e-5 m × 2,99792458e13 Hz = 299792458 m/s`. In modernen SI-Einheiten ist dieser Wert exakt definiert; ein Labor testet eher die Übereinstimmung der elektromagnetischen Beziehungen mit seinen unabhängig realisierten Uhren und Längennormalen.

Beispielsweise Wasserstoff/Deuterium werden im beigefügten Code aus dem **nichtrelativistischen** Rydberg-Modell (übernommener `R_infty`, reduzierte Masse, keine Fitparameter) verglichen. Die unterschiedlichen Isotopenmassen verschieben die Linie; sie ändern nicht `c`. Präzisions-QED- und Kernkorrekturen sind im Modell nicht enthalten.

## 4. Warum die Planck-Rückrechnung allein G nicht erklärt – harter Negativtest

```
l_P = sqrt(hbar G/c^3),   t_P = sqrt(hbar G/c^5),
l_P/t_P = c.
G = c^3*l_P^2/hbar.
```

Die letzte Zeile rechnet `G` korrekt aus, **wenn** `l_P` unabhängig als physikalische Länge ermittelt wurde. Werden `l_P` und `t_P` vorher aus `G` definiert, ist das eine Identität, keine Erklärung für den Wert von `G`.

**Identifizierbarkeits-Gegenprobe:** Setzen wir gedanklich `G' = 4G`, so würden bei gleichem `c,hbar` beide abgeleiteten Planck-Einheiten verdoppelt: `l_P'=2l_P`, `t_P'=2t_P`. Weiterhin gilt `l_P'/t_P'=c`, und jede unveränderte 10-µm-Linie erfüllt `lambda/l_P'=T/t_P'` – aber N halbiert sich. Genau das beweist: Aus den Spektralgleichheiten alleine kann der Zahlenwert von G nicht identifiziert werden.

Ebenso lässt die hypothetische Gleichsetzung von `G*m_p²/lambda` und `h*c/lambda` die Wellenlänge vollständig herausfallen; sie erfordert ein `G` um etwa `1,064e39` größer als gemessen. Dies ist ein Negativtest einer willkürlichen Gleichsetzung, nicht der gesamten CIQ-Kontrastidee.

## 5. Physikalischer Zugang zu G über eine gravitative Spektralverschiebung

Für eine Lichtquelle A und einen Empfänger B, beide statisch außerhalb einer kugelsymmetrischen, nicht rotierenden Gravitationsquelle M, liefert die Schwarzschildlösung:

```
q = nu_B/nu_A = sqrt[(1 - 2GM/(c² r_A))/(1 - 2GM/(c² r_B))],
K_IR = 1/q.
```

Mit `y = q²` folgt durch algebraische Umkehrung:

```
G = (c²/(2M)) * (1-y)/(1/r_A - y/r_B).
```

**Dies ist ein prinzipieller Weg zur Messung von G aus gravitativer Spektralverschiebung, sofern M, r_A, r_B und die Bewegungen der Empfänger/Quelle unabhängig ermittelt werden.** Er setzt bereits die Gültigkeit der Einstein-/Schwarzschild-Beschreibung voraus. Falls M durch dieselben Gravitationsmessungen bestimmt wurde, wird die Methode zirkulär. Aus einer Spektrallinie ohne solche Zusatzinformationen folgt G nicht.

**Synthetischer, transparenter Algebra-Test (keine unabhängige Bestimmung):** Vorgabe `M=1,98847e30 kg`, `r_A=100 km`, `r_B=200 km`, `G=6,67430e-11` zur Simulation des Shifts. Resultat:

```
r_s = 2953,3393821 m
q = nu_B/nu_A = 0,9924776972477319
K_IR = 1,0075793166668918
lambda_B(10µm) = 10,0757931666689 µm
G_rueck = 6,674300000000011e-11 m³/(kg s²)
```

Der Test rekonstruiert die Eingabe G; er überprüft nur die Algebra und numerische Stabilität. Die **gemeinsame** relativistische Verschiebung `K_IR` gilt für jede gleichzeitig ausgesandte Linie (unter gleichen Wegen, ohne Dispersion oder Quellenmischung), nicht nur im IR-Bereich. `results/gravitations_rotverschiebung_spektrallinien.csv` enthält die individuellen Werte.

Im schwachen Erdschwerefeld beträgt die relative Verschiebung über einen Höhenunterschied von 1 m `g*h/c² ≈ 1,091e-16`; die entsprechende Verschiebung der 10-µm-Frequenz beträgt ca. `0,00327 Hz`. Dabei würde die Messung von `g` zunächst die Gravitationsstärke lokal bestimmen – für G ist zusätzlich eine unabhängige Kenntnis der verursachenden Masse nötig.

## 6. Dein Sinus/Cosinus- und 2D/3D-Prinzip als getrennter geometrischer Test

In planckkalibrierten Koordinaten `X=x/l_P`, `Theta=t/t_P` und einem Photon mit N:

```
phi_x = 2*pi*X/N,
phi_t = 2*pi*Theta/N,
phi = phi_t - phi_x.
```

Die zu prüfende getrennte Zuordnung `sin(phi_x)` (Länge) und `cos(phi_t)` (Zeit) hat **nur entlang der Lichtfront `x=ct`** den konstanten Phasenversatz 90°, weil dann `phi_x=phi_t`. Bei anderen Beobachterbahnen kann die relative Phase fortschreiten. Ein konsistentes Lichtfeld lässt sich mit der **gemeinsamen** Phase `phi` darstellen; die getrennte Sin/Cos-Aufteilung allein definiert noch keine neue Raumzeit.

Eine 2D-Richtung `u=(cos θ,sin θ)` liefert den symmetrisch-spurfreien Quadrupol:

```
Q_xx = u_x²-u_y² = cos(2θ)
Q_xy = 2*u_x*u_y = sin(2θ)
```

Bei einer Drehung um 90° wechseln beide Vorzeichen; bei 180° ist der Tensor unverändert. Das ist eine **exakte mathematische Spin-2-artige Winkelstruktur** durch einen quadratischen 2D-Ausdruck. Sie erzeugt jedoch ohne Dynamik keinen gravitativen Freiheitsgrad, kein universelles IR-Fenster und keinen Zahlenwert von G. `results/quadrupol_2theta_test.csv` ist der reproduzierbare Geometrietest.

## 7. Oberflächenenergie, Entropie, IR und Gravitation – Geltungsbereich

Eine Oberfläche kann reale Energie `E_surface = integral sigma dA` tragen; ihr Energie-Impuls-Tensor gravitiert, und ein warmer Körper kann IR-Photonströme mit Entropie erzeugen. Die thermische Strahlung hängt aber von Temperatur und Emissivität ab; 10 µm ist keine universelle Emissionslinie aller Atomkerne. Die isotopensensitive Rydbergverschiebung entsteht schon durch die reduzierte Elektron-Kern-Masse. Eine zusätzliche Oberflächen-/Kontrastquelle erfordert eine **eigenständige, lokal konservierte Tensorquelle**, etwa im Rahmen von Israel-Grenzbedingungen, und deren gemeinsame Einstein-Dynamik.

Eine Definition wie `G=c³l_P²/hbar` darf nicht als unabhängige Erklärung der Gravitationskonstante benutzt werden, solange die Planck-Länge nur aus G berechnet wurde. Für einen echten CIQ-Vorhersagetest wäre eine unabhängig begründete Längenskala/Operatornormierung nötig, die G und beobachtete Frequenzshifts **ohne G als verborgene Eingabe** vorhersagt.

## 8. Reproduzierbarkeit

Die bisherige ZIP-Originalversion, der ältere Spektrallinien-Rückwärtstest und der historische EW-Negativbefund liegen unverändert im Unterordner `quellen_originale`. Deren spätere Korrekturen werden in diesem Bericht als neue Entwicklungsetappe kenntlich gemacht; ursprüngliche Dateien werden nicht überschrieben.

```
python3 code/spektral_cg_phase_audit.py
```

Nur Python-Standardbibliothek. Es entstehen `results/spektral_planck_ir.csv`, `results/doppler_ir_operator.csv`, `results/gravitations_rotverschiebung_spektrallinien.csv`, `results/quadrupol_2theta_test.csv` und `results/rechenwerte_und_tests.json`.

**17/17 neue interne Kontrollen bestanden**, darunter Konstanz `c`, Energie-/Planck-Kopplung, Doppler-K, G-Inversion der synthetischen Probe, alle Spektrallinien mit demselben gravitativen K, quadratisches Doppelwinkel-Verhalten und ein G-Nicht-Identifizierbarkeits-Test. Keine der 17 Kontrollen ist eine unabhängige experimentelle Bestätigung.

## 9. Prüfurteil und offener Anschluss

- **[D PASS]** Die Planck-gekoppelte Energie-, Längen- und Zeitbeschreibung ist für jede Vakuum-Spektrallinie konsistent.
- **[D PASS]** `c=lambda*nu` folgt direkt aus lokal gemessenen Spektraldaten.
- **[D PASS]** Gravitative Rotverschiebung trägt unter angegebenen Annahmen G und lässt eine Rückwärtsbestimmung prinzipiell zu.
- **[NEG]** Ein freier Wert von G ist aus unverschobenen Spektrallinien und den bereits aus G definierten Planck-Einheiten allein nicht berechenbar.
- **[D PASS]** Die quadratische 2D-Geometrie erzeugt 2θ, ist aber kein Beweis einer 2D-zu-3D-Phasentransformation oder des Ursprungs von G.
- **[O]** Eine universelle zusätzliche IR-Oberflächenkopplung ist offen; die bisherige Ising-EW-Brücke liefert keinen gültigen Wert dafür.

**Nächster eindeutiger Falsifikationstest:** Eine von G unabhängige, nicht nachträglich angepasste Oberflächen-IR-Kopplung konkretisieren, ihre Tensorquelle und Dispersion berechnen, dann für sichtbare, IR- und Radiolinien im selben Gravitationspotential testen, ob die relativen Shifts über die allgemein-relativistische, frequenzunabhängige Vorhersage hinaus voneinander abweichen.

## 10. Referenzgrundlagen

- NIST/CODATA 2022: https://physics.nist.gov/cuu/Constants/
- NIST: https://www.nist.gov/publications/codata-recommended-values-fundamental-physical-constants-2022
- Optische Uhren/Gravitationsrotverschiebung: https://www.nature.com/articles/s41467-023-40629-8
- NIST-Licht- und Plank-Konstanten: https://www.nist.gov/si-redefinition/meet-constants
- Nutzereigene historische Originale: siehe `quellen_originale/`.
