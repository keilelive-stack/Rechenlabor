#!/usr/bin/env python3
"""Prueft die ausgelieferten Dateien, neue Ausgabedateien werden ignoriert."""
from pathlib import Path
import hashlib,zipfile,sys
root=Path(__file__).resolve().parent
bad=[];n=0
for line in (root/'MANIFEST_SHA256.txt').read_text(encoding='utf-8').splitlines():
    digest,rel=line.split('  ',1);p=root/rel;n+=1
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:bad.append(rel)
for p in (root/'originale').glob('*.zip'):
    try:
        with zipfile.ZipFile(p) as z:
            if z.testzip() is not None:bad.append(p.name+' CRC')
    except zipfile.BadZipFile:bad.append(p.name+' ZIP')
print(f'{n-len([x for x in bad if not x.endswith((" CRC"," ZIP"))])}/{n} SHA-256-Dateien korrekt; ZIP-CRC geprueft.')
for x in bad:print('FAIL',x)
sys.exit(bool(bad))
