#!/usr/bin/env python3
"""Originalprogramme aus Kopien ausfuehren, Original-ZIPs nie aendern."""
import argparse, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--ns-original',action='store_true',help='auch den langsameren originalen NS-Scan ausfuehren');a=ap.parse_args()
    jobs=[('CIQ_IR_Planck_Bezug_Kruemmung*',['code/audit.py','code/bezugssystem_und_lichtgravitation.py','code/ir_ursache_raum_audit.py']),('CIQ_IR_Planck_cG*',['code/spektral_cg_phase_audit.py']),('CIQ_GEMEINSAMER*',['code/ir_operator_pruefung.py']),('CIQ_Herleitung*',['code/ciq_c_g_ir_audit.py']),('CIQ_IR_3D*',['code/phase3d_nachtest.py']),('CIQ_Gravitation*',['pruefcode.py']),('CIQ_Ising_3D*',['ising-suite/tests_coupled.mjs','ising-suite/tests_transfer3d.mjs'])]
    if a.ns_original:jobs.append(('CIQ_NS*',['run_audit.py']))
    out=ROOT/'ergebnisse'/'legacy';out.mkdir(parents=True,exist_ok=True);results=[]
    for pattern,scripts in jobs:
        zpath=next((ROOT/'originale').glob(pattern+'.zip'))
        with tempfile.TemporaryDirectory() as td:
            with zipfile.ZipFile(zpath) as z:
                if z.testzip() is not None:raise ValueError('CRC Fehler '+zpath.name)
                for n in z.namelist():
                    if not Path(td,n).resolve().is_relative_to(Path(td).resolve()):raise ValueError('Unsicherer ZIP Pfad')
                z.extractall(td)
            for script in scripts:
                p=next((p for p in Path(td).rglob(Path(script).name) if p.as_posix().endswith(script)),None)
                if p is None:raise FileNotFoundError(script)
                cmd=[sys.executable if p.suffix=='.py' else 'node',str(p)]
                if p.suffix=='.mjs' and not shutil.which('node'):
                    results.append(dict(archive=zpath.name,script=script,status='SKIP: Node.js fehlt'));continue
                cwd=p.parent if p.suffix=='.mjs' or p.parent.name!='code' else p.parent.parent
                r=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,env={**os.environ,'MPLBACKEND':'Agg'},timeout=600)
                log=out/(p.stem+'.log');log.write_text(r.stdout,encoding='utf-8');results.append(dict(archive=zpath.name,script=script,status='PASS' if r.returncode==0 else 'FAIL',returncode=r.returncode,log=log.name));print(script,results[-1]['status'],flush=True)
    (out/'status.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');return int(any(x['status']=='FAIL' for x in results))
if __name__=='__main__':sys.exit(main())
