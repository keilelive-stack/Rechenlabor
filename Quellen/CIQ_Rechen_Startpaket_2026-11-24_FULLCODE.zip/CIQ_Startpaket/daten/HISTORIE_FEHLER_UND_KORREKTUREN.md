# Chronologie: ursprüngliche Behauptung → späterer Befund → Umsetzung (nicht rückwirkend geändert)

| Ursprüngliche Entwicklung | Spätere Gegenprüfung | Behandlung in v3 |
|---|---|---|
| 2D-Projektion sei 3D-Geometrie | Rang-2-Fläche alleine ist nicht 3D; unabhängige Tiefe nötig | Separate Auswahl der Weg-/Tiefeninformation, unbekannt bleibt unbekannt |
| Winkel aus `(θx,θy,1)` | Exakt nur bei Richtungssteigungen, sonst Tangens | Volle sphärische Winkelparametrisierung eingeführt |
| Nur drei Beobachter genügen immer für 3D | Planare Empfänger lassen Spiegel- oder Phasen-Aliase | 4 nicht-koplanare Empfänger; expliziter Alias-Blocker |
| IR-Linien liefern automatisch eine absolute optische Phase | Thermische Spektrallinien liefern Frequenzreferenz, Kohärenz erfordert Interferometer | Rein synthetischer kohärenter 3D-Phasentest, keine unbelegten realen Phasendaten |
| Winkel/Laufzeit durch W ohne feste Normierung | Richtungsableitung benötigt transversale Längenkoordinate; α=−∂bW, W=cΔt | Definierte Optische Wegdifferenz und GR-Referenzpfad |
| Interne Schwarzschild-Massenformel für IR | Ausgedehnte GR-Fluidquelle benötigt vollständiges ν(r) | `Kgrav=exp(νB−νA)`; GR-TOV-Eingang |
| `gBar`, `gObs` in exportierter SPARC-JSON zu 0 gerundet | Unterdrückte Exponentialschreibweise | Neue korrigierte JSON, historisches Original unverändert |
| Ising-Domänen bereits gravitative Quelle | Fehlende geschlossene Wärmebad-/Archiv-Bilanz und dynamischer Tensor | Memory nur als Diagnose angezeigt, keine erdichtete Ising-Einwirkung auf GR |
| Rein konforme Metrik liefere Lensing | Konforme Minkowski-Metrik erhält Nullgeodäten | Nicht für physikalisches Lensing verwendet; GR-Nullreferenz |
| Ising-D=7/4 sei geometrische Hülle | 7/4 Perkolationshülle; Ising-Hüllen je nach Clusterdefinition verschieden | Historie beibehalten, nicht als Fixparameter eingesetzt |

**Regel:** Die beigefügten älteren Archive sind binär unverändert und dokumentieren die ursprünglichen Ideen; neue Korrekturen bilden eine zusätzliche, getrennte Stufe.
