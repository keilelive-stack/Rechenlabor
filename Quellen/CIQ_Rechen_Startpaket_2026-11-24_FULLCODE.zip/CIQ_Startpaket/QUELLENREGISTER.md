# Quellenregister und Provenienz
Stand 24.11.2026. Die Dateien in `originale/` sind bytegleiche Kopien der 15 in diesem Chat hochgeladenen Originale. Die SHA-256-Liste deckt alle ausgelieferten Dateien ab. Keine externen Drive-Dateien oder neuen Literaturdaten wurden für dieses Paket abgerufen.

| Quelle (Originaldatei) | Nutzung |
|---|---|
| FORSCHUNGSBERICHT_HERLEITUNG.pdf | Abschnitte 2–7: Konstanten, Planck, IR; 8–9: Phase und Tensor; 12–14: G-Inversion; 15–18: Prüfgrenzen. |
| CIQ_Herleitung_c_G_Planck_IR_Chatrekonstruktion_2026-11-10.zip | Originalcode `code/ciq_c_g_ir_audit.py`, erneut ausgeführt. |
| CIQ_IR_Planck_Bezug_Kruemmung_Audit_2026-11-10.zip | `code/audit.py`, `bezugssystem_und_lichtgravitation.py`, `ir_ursache_raum_audit.py`, erneut ausgeführt. |
| CIQ_IR_Planck_cG_Spektral_Phase_2026-11-10.zip | `code/spektral_cg_phase_audit.py`, erneut ausgeführt. |
| CIQ_GEMEINSAMER_IR_OPERATOR_PLANCK_SPEKTRAL_GEOMETRIE_2026-11-10.zip | `code/ir_operator_pruefung.py`, erneut ausgeführt. |
| PRUEFBERICHT_IR_REFERENZ.md; PRUEFBERICHT_VERBINDUNG.md; PRUEFBERICHT gemeinsame Geometrie c und G.md | Begleitende historische Prüfberichte. |
| CIQ_IR_3D_Phasenpeilung_Nachtest_2026-11-11_FULLCODE.zip | `code/phase3d_nachtest.py`, erneut ausgeführt; 3D-Phasenbeispiel und Rauschen. |
| CIQ_Gravitation_Hubble_Beobachtungsradius_Audit_2026-11-11.zip | `pruefcode.py`, erneut ausgeführt; kosmologische Referenz und Gegenproben. |
| PRUEFBERICHT_DE(20261111-111351).md | Begleitender historischer Prüfbericht, unverändert erhalten. |
| CIQ_Ising_3D_Transfer_Metrik_Forschungsbericht.docx | Abschnitte 2–8: 3D, TOV-Weg, SPARC, Prüfstatus. |
| CIQ_Ising_3D_Transfer_Metrik_Upgrade_2026-11-11_FULLCODE.zip | `code/prepare_data.py` dokumentiert fehlenden externen Solver; `ising-suite/tests_coupled.mjs` und `tests_transfer3d.mjs` erneut ausgeführt. |
| CIQ_CROSS_3D_TRANSFER_METRIK_OFFLINE.html | Historische Offline-Simulation, unverändert; Ising-/XY-/IR-Nullvertrag. |
| CIQ_NS_Massengrenze_TOV_Entropie_Audit_FULLCODE.zip | `README_DE.md`, `run_audit.py`, `resultate.json`: EOS, Randbedingung, historische Maxima. Originalprogramm optional ausführbar, neue gemeinsame TOV-Implementierung tatsächlich ausgeführt. |

## Extrahierte Referenzen
`daten/TOV_REFERENZ_HISTORISCH.json` und `TOV_IR_LENSING_HISTORISCH.json` stammen aus `quellen/` im 3D-Transfer-ZIP. `gr_tov_path_reference.json`, `sparc_raw_reference_corrected.json`, `sparc_raw_reference_ORIGINAL_2026_11_11.json` stammen aus `ising-suite/src/data/` desselben Archivs. `HISTORIE_FEHLER_UND_KORREKTUREN.md` stammt aus dessen Wurzel. `ns_resultate_historisch.json` ist die unveränderte `resultate.json` des NS-Archivs.

## Neue Implementierung und Abgrenzung
`code/ciq.py`, `start.py`, `messung.py`, `legacy_tests.py`, Eingabedateien und dieses Handbuch wurden neu erstellt. Der dimensionslose TOV-Kern und die analytische n=1-Polytropen-Rekonstruktion sind neue Implementierungsentscheidungen. Die historischen Sollwerte werden nicht in den Solver eingespeist. Das NS-Oberflächenkriterium stammt aus dem Original; die numerische Zustandsvariable und Suche nach dem ersten lokalen Maximum wurden neu gewählt. Der historische Halo-Solver selbst ist nicht enthalten. Neue Rechnungen und historische Ergebnisse werden getrennt aufbewahrt. Die vollständige spätere CIQ-Ising-v7.7- und RH-Forschung ist nicht in diesem Paket.
