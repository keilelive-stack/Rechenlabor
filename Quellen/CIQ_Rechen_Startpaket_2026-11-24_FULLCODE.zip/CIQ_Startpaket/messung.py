#!/usr/bin/env python3
"""Auswertung explizit eingegebener Spektral-/Phasenmessungen, keine Ursachenerfindung."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'code'))
from ciq import *

def evaluate(d):
    if not d.get('provenance'):raise ValueError('Datenherkunft angeben')
    a=d['lambda_A_um']*1e-6;b=d['lambda_B_um']*1e-6;k=K_ir(a,b)
    result={'provenance':d['provenance'],'K_total':k,'z_total':k-1,'A':spectrum(a),'B':spectrum(b),'cause':'nicht aus K allein bestimmbar','gravitation':None,'interferometrie':None}
    g=d.get('gravitation')
    if g is not None:
        if g.get('static_exterior_schwarzschild') is not True or not g.get('geometry_provenance') or 'K_grav_isolated' not in g:raise ValueError('Nur isolierter gravitativer Faktor und belegte statische Aussengeometrie')
        rs=invert_rs(g['K_grav_isolated'],g['r_A_m'],g['r_B_m']);result['gravitation']={'rs_m':rs,'GM_m3_s2':C*C*rs/2,'G_m3_kg_s2':None}
        if g.get('mass_kg_independent') is not None:
            if not g.get('mass_provenance'):raise ValueError('Unabhaengige Massenherkunft angeben')
            positive(g['mass_kg_independent']);result['gravitation']['G_m3_kg_s2']=C*C*rs/(2*g['mass_kg_independent'])
    p=d.get('interferometrie')
    if p is not None:
        r=phase_invert(p['baselines_m'],p['phases_rad'],p.get('lambda_min_m_independent'),p.get('unwrapped',False),p.get('depth_m_independent'));r['K_phase']=r['lambda_m']/a;r['K_phase_minus_spectral']=r['K_phase']-k;result['interferometrie']=r
    return result
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('input',type=Path);a=ap.parse_args();print(json.dumps(evaluate(json.loads(a.input.read_text(encoding='utf-8'))),ensure_ascii=False,indent=2,allow_nan=False))
