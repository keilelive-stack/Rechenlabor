# CIQ – eigenständiges Rechen-Startpaket
Stand 24.11.2026 | IR-Planck, 3D-Transfer, TOV, SPARC, Hubble und Ising-Cross v3

**Kein Vorwissen über CIQ und keine Chat-Erinnerung erforderlich.** Das Paket enthält eine neue, unabhängige Rechenimplementierung auf Grundlage der hochgeladenen historischen Quellen. Es ist kein vollständiger Export von Ising v7.7 oder RH-01–39.

## Einstieg für Menschen und KI
1. ZIP vollständig entpacken. `ANLEITUNG.pdf` oder `ANLEITUNG.md` lesen. Für eine neue KI zusätzlich `START_FUER_KI.txt` verwenden.
2. Python 3.10 oder neuer installieren, Terminal im entpackten Ordner öffnen.
3. `python -m pip install -r requirements.txt` (Internet oder lokaler Paketcache nötig; danach laufen die Berechnungen offline).
4. `python verify.py` prüft den mitgelieferten Dateistand. Danach `python start.py --out neuer_lauf` ausführen. Standard: 49/49 PASS. `--quick` berechnet nur zwei NS-Maxima (37/37). Nicht die Original-Ergebnisse überschreiben, wenn sie verglichen werden sollen.
5. Eigene Eingaben: `beispiele/eingaben.json` kopieren, ändern, `python start.py --input meine_eingaben.json --out mein_lauf`. Historische Sollwertprüfungen gelten nur bei unveränderten Standardeingaben. Nicht alle beliebigen Parameter ergeben gültige Modelle.
6. Messung statt synthetischem Test: `python messung.py beispiele/messung.json`. Die Datei ist ausdrücklich synthetisch. Für echte Daten die Vorlage kopieren und Messherkunft dokumentieren. Siehe Anleitung, Abschnitt 3.
7. Historische Programme separat: `python legacy_tests.py` (Node.js für zwei Ising-Tests, Matplotlib für Phasenplots). Optional `--ns-original` für den alten NS-Code. Die Originale werden in temporäre Verzeichnisse entpackt. Die neue Implementierung benötigt kein Node.js und keinen historischen externen TOV-Solver.
8. Offline-Visualisierung: `originale/CIQ_CROSS_3D_TRANSFER_METRIK_OFFLINE.html` im Browser öffnen. Sie zeigt die historischen vorab berechneten TOV-Daten; sie ist nicht automatisch mit neuen Python-Eingaben synchronisiert.

## Dateien
- `code/ciq.py`: Formeln und gemeinsamer neuer TOV-Solver.
- `start.py`: Referenzrechnungen, Gegenprüfungen, CSV/JSON-Ausgaben.
- `messung.py`: getrennte Auswertung expliziter Messwerte, ohne Ursache aus K zu erraten.
- `legacy_tests.py`: erneute Ausführung historischer Prüfprogramme.
- `beispiele/`: Standardeingaben und Messvorlage.
- `daten/`: historische Referenzen und SPARC-Original/Korrektur.
- `ergebnisse/`: tatsächlich erzeugte Ergebnisse, Protokolle, Vergleichswerte.
- `originale/`: 15 unveränderte Uploads (ZIP, PDF, DOCX, MD, HTML).
- `QUELLENREGISTER.md`: Herkunft und Status; `MANIFEST_SHA256.txt`: Integrität.

## Status
49/49 neue Standardprüfungen und 10/10 separat ausgeführte historische Programme bestanden. Die zwei Node-Programme melden 81/81 und 248/248 technische Checks. Kein React-Produktionsbuild oder Browser-Automation in diesem Lauf; der historische NS-Code wurde nicht separat neu ausgeführt, aber alle acht NS-Maxima wurden mit dem neuen Solver nachgerechnet. Keine empirische Bestätigung einer zusätzlichen CIQ-Gravitation. Der historische externe `gr_quellenreferenz.py` fehlt; der neue Solver ersetzt dessen Rechenfunktion, nicht seine Originaldatei.
