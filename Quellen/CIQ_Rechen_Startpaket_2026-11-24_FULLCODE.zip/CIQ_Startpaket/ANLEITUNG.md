# CIQ | Rechnen ohne Vorwissen
Eigenständiges Rechenhandbuch · Version 1.0 · 24. November 2026

## 1. Was dieses Paket leistet
CIQ ist hier ein Übersetzer: Ein geometrisches Gedankenbild wird in definierte Messgrößen, Gleichungen, numerische Rechnungen und prüfbare Ergebnisse überführt. Es ist keine neue Gravitationstheorie. Dieses Handbuch beschreibt die tatsächlich vorliegenden historischen Module vom 10.–11. November und den ergänzenden Neutronenstern-TOV-Audit vom 26. Oktober. Die vollständige spätere Ising-v7.7-Suite und die RH-Register sind nicht Teil dieser Lieferung.

**Reihenfolge:** Messgröße → Geometrie → physikalische Annahme → Rechnung → unabhängige Gegenprobe → Interpretation. Keine Anpassung an erwartete Zahlen. Parameter, die ein Modell benötigt, werden ausdrücklich angegeben; No-Fit bedeutet nicht, dass es keine Eingaben gibt.

**Schnellstart:** ZIP entpacken, Python 3.10+ installieren und im Ordner ein Terminal öffnen. Abhängigkeiten einmalig installieren. Danach sind alle Rechenwege lokal ausführbar.

```
python -m pip install -r requirements.txt
python verify.py
python start.py --out neuer_lauf
```

Die mitgelieferten Standardergebnisse stehen in `ergebnisse/pruefergebnisse.json`. Der neue Lauf muss 49/49 Prüfungen bestehen. `--quick` führt 37 Prüfungen aus. Mit `--input` eine eigene JSON-Datei übergeben; die historischen Vergleichstests werden dann nicht erzwungen. Originale und Sollwerte bleiben getrennt.

**Für eine neue KI:** Datei `START_FUER_KI.txt` lesen. Keine Erinnerung, keine weiteren Chatprotokolle und keine externen Drive-Ordner voraussetzen.

## Ergebnisarten
- [M] Mathematische Identität: folgt aus Definitionen.
- [S] Standardphysik: gilt unter ausdrücklich angegebenen Voraussetzungen.
- [H] Hypothese oder Testmodell: zusätzliche Annahme, kein Nachweis.
- [T] Synthetische/numerische Kontrolle: bekannte Eingaben werden vorwärts oder rückwärts geprüft.
- [E] Empirischer Datensatz: gemessene Werte mit dokumentierter Herkunft. Abgeleitete Spalten sind keine neuen Messungen.
- [O] Offen: fehlende Messgröße, Quelle, Feldgleichung oder Validierung.

<!-- page -->
# 2. Gemeinsame Einheiten und IR-Operator
## 2.1 Grundgrößen [M/S]
Rechne intern in SI. Wellenlänge λ in m, Frequenz f in Hz, Periodendauer T in s, Energie E in J. 1 µm = 10⁻⁶ m; 1 nm = 10⁻⁹ m; 1 fm = 10⁻¹⁵ m. 1 kpc = 3,085677581491367 × 10¹⁹ m. 1 Mpc = 1000 kpc. Ein Lichtjahr = c × 31 557 600 s. Sonnenmassenreferenz = 1,98847 × 10³⁰ kg (gewählter Referenzwert, nicht exakt gemessene Masse).

c = 299 792 458 m/s; h = 6,62607015 × 10⁻³⁴ J s; ħ = h/(2π); k_B = 1,380649 × 10⁻²³ J/K. G = 6,67430 × 10⁻¹¹ m³/(kg s²) ist ein empirischer Referenzwert, nicht exakt definiert. Seine CODATA-2022-Standardunsicherheit beträgt 0,00015 × 10⁻¹¹ in denselben Einheiten.

**Formelkette:** f = c/λ; T = λ/c; E = hf; ℓ_P = √(ħG/c³); t_P = ℓ_P/c; E_P = ħ/t_P. Daraus folgt c = λ/T = λf = ℓ_P/t_P und N = λ/ℓ_P = T/t_P = 2π E_P/E. N ist eine Verhältniszahl, keine nachgewiesene diskrete Schrittzahl.

## 2.2 Fester Referenzanker
λ_ref = 10,000000 µm = 10⁻⁵ m. Daraus f_ref = 29,9792458 THz; T_ref = 33,3564095 fs; E_ref ≈ 0,1239842 eV; N_ref ≈ 6,1871424 × 10²⁹. Der Anker bleibt fest, auch wenn eine andere Spektrallinie gemessen wird. Er ist ein Vergleichsmaßstab, kein universeller physikalischer Spektralübergang.

## 2.3 Unveränderter Operator [M]
A = Quelle/Laborreferenz, B = Empfangsmessung. Beide Wellenlängen müssen zur selben identifizierten Vakuumlinie bzw. zu einem definierten Vergleichssignal gehören. Für eine andere Elementlinie ist λ_A deren eigene Laborwellenlänge, nicht 10 µm.

**K_IR = λ_B/λ_A = f_A/f_B = T_B/T_A = E_A/E_B = N_B/N_A.** Rotverschiebung z = K_IR − 1. K > 1 bedeutet längere Wellenlänge bei B. Beispiel: 10 → 11 µm ergibt K = 1,1 und f_B = 27,2538598 THz. Die auf 10 µm übertragene Vergleichswellenlänge ist K × 10 µm; sie ist nicht automatisch eine tatsächlich beobachtete IR-Linie.

Für zwei Linien: D = K_2/K_1. Bei gleichem Weg und achromatischer Verschiebung ist D = 1. Prüfe Unsicherheiten, Luft/Vakuum, Linienidentifikation, Quellenbewegung und Kalibrierung. Ein gemeinsamer Faktor ist noch kein Beweis für seine Ursache.

<!-- page -->
# 3. Vom Spektrum zur Gravitation
## 3.1 Ursachen nicht vermischen [S]
Radialer relativistischer Dopplerfaktor: K_D = √((1+β)/(1−β)), β = v/c, positiv bei Entfernung. Umkehrung β = (K_D²−1)/(K_D²+1). Bei β = +0,6 ergibt sich K_D = 2, bei −0,6 K_D = 0,5. Der Lorentzfaktor γ = 1/√(1−β²) ist bei 0,6 dagegen 1,25. Eine Frequenzverschiebung ist nicht generell gleich der Zeitdilatation eines bewegten Beobachters.

In einer geeigneten getrennten Modellierung gilt K_total = K_D K_grav (1+z_cos). Allgemein ist die lokal gemessene Kreisfrequenz ω = −k_μ u^μ; K = ω_A/ω_B. Eine einzelne Spektrallinie liefert nur K_total, nicht drei unabhängige Ursachen. Für eine Inversion müssen Bewegungen, Geometrie und weitere Beiträge bekannt sein.

## 3.2 Schwarzschild-Außengeometrie [S]
Nur statische Beobachter im Vakuum außerhalb einer kugelsymmetrischen, nicht rotierenden Masse; r_A, r_B > r_s. Definiere g00 als positiven Betrag der normierten Zeitmetrik: g00(r) = 1−r_s/r. Dann dτ/dt = √g00 und K_grav = √(g00_B/g00_A).

**Inversion:** r_s = (K_grav²−1)/(K_grav²/r_A−1/r_B). Daraus GM = c²r_s/2. Erst bei unabhängig bekannter Masse M in kg: G = c²r_s/(2M). Gleich große Radien, Horizont oder unzulässige negative Masse blockieren die Rechnung. Für r_B → ∞ gilt r_s = r_A(1−1/K²). Lokale Oberflächenbeschleunigung statischer Beobachter: g = GM/(r²√(1−r_s/r)); im schwachen Feld g ≈ GM/r².

Synthetischer Test: M = 1,98847 × 10³⁰ kg, r_A = 100 km, r_B = 200 km. Vorwärts mit Referenz-G erzeugtes K ≈ 1,0075793. Rückwärts r_s ≈ 2953,34 m und G ≈ 6,67430 × 10⁻¹¹. Das ist [T], keine unabhängige G-Messung. In realen astronomischen Bahndaten ist oft nur GM unabhängig bestimmt.

## 3.3 Planck-Rückrechnung und Messmodus
G = c³ℓ_P²/ħ = c⁵t_P²/ħ. Wurde ℓ_P aus G berechnet, ist die Umkehrung zirkulär. Gegenprobe G → 4G: ℓ_P und t_P verdoppeln sich, N halbiert sich, c und K bleiben unverändert. Für kleine K−1 sind relative Unsicherheiten des Verschiebungssignals entscheidend; keine scheinexakten Nachkommastellen ausgeben.

`python messung.py beispiele/messung.json` wertet eine getrennte Messvorlage aus. Für Gravitation das Objekt `gravitation` mit `K_grav_isolated`, `r_A_m`, `r_B_m`, `static_exterior_schwarzschild: true` und `geometry_provenance` befüllen. Optional `mass_kg_independent` und `mass_provenance`; ohne unabhängige Masse bleibt G null. Der Code kann die physikalische Herkunft der eingegebenen Angaben nicht selbst beweisen.

<!-- page -->
# 4. Phasengeometrie und 3D-Transfer
## 4.1 Von Sinus/Cosinus zum Wellenvektor [M/S]
Setze X = x/ℓ_P, Θ = t/t_P. Getrennte Darstellungen sin(2πX/N), cos(2πΘ/N) erfüllen auf x = ct die Quadratur sin² + cos² = 1. Die gemeinsame Wellenphase φ = 2π(t/T − x/λ) bleibt auf dieser Lichtfront konstant. Raum und Zeit sind nicht global zwei automatisch quadraturgekoppelte Signale. Für u = (cos θ, sin θ) gilt Q = 2uuᵀ − I mit Q_xx = cos(2θ), Q_xy = sin(2θ), Q_yy = −cos(2θ). Die Doppelwinkeltransformation ist noch kein dynamisches Spin-2-Feldgesetz.

## 4.2 Messanordnung
Vier Empfänger A, B, C, D; drei Basisvektoren relativ zu A. Die Zeilen der 3×3-Matrix B sind die Basisvektoren in m. Phasenkonvention Δφ_j = b_j · k in rad, modulo 2π. k zeigt in Ausbreitungsrichtung, die Quelle liegt in Gegenrichtung. Nur mit kalibrierter kohärenter Messung bzw. komplexer Sichtbarkeit arbeiten, nicht mit einer Spektrallinie allein.

**Rechenweg:** k = B⁻¹ Δφ; λ_obs = 2π/|k|; n = k/|k|; K_IR = λ_obs/λ_rest. Azimut = atan2(n_y,n_x); Polarwinkel zur +z-Achse = arccos(n_z). Elevation = 90° − Polarwinkel. Für bekannte unabhängige Entfernung d: Quellposition relativ zu A = −d n. Ohne d keine Position, nur Richtung.

Bei gefalteten Phasen muss eine unabhängige Untergrenze λ_min bekannt sein und jede Basis strikt kürzer als λ_min/2 sein, oder die ganzzahligen 2π-Zyklen müssen separat entrollt werden. Rang 3 und gute Konditionierung sind erforderlich. Planare Basen lassen Spiegelmehrdeutigkeit. Längere Basen können auch bei vier Empfängern Aliase erzeugen.

## 4.3 Durchgerechneter synthetischer Test [T]
λ_rest = 10 µm; λ_obs = 11 µm; Basis = 3 µm je x, y, z; Azimut = 32°; Polarwinkel = 40°. n ≈ (0,545115; 0,340626; 0,766044). Δφ ≈ (0,934107; 0,583695; 1,312691) rad. Inversion ergibt λ_obs = 11 µm, K = 1,1 und die ursprünglichen Winkel. Mit Seed 271828, 1200 Rauschrealisierungen und σ = 0,002 rad: Median Winkelfehler 0,07625°, 95. Perzentil 0,16368°. Die im Standardtest eingesetzte unabhängige Wellenlängen-Untergrenze ist 0,9 × der synthetischen λ_obs; bei realen Daten muss sie separat bekannt sein.

`messung.py` nimmt unter `interferometrie` die Basismatrix, Phasen, `lambda_min_m_independent` oder `unwrapped: true` und optional `depth_m_independent` an. Bei unbekannter Tiefe bleibt die Position null. Ein FLRW-Abstand aus z ist modellabhängig und keine unabhängige Tiefenmessung.

<!-- page -->
# 5. Gemeinsamer TOV-Rechenkern
## 5.1 Was ist TOV? [S]
Tolman–Oppenheimer–Volkoff beschreibt einen statischen, kugelsymmetrischen, nicht rotierenden Körper aus isotroper perfekter Flüssigkeit. Eingaben: Zustandsgleichung (EOS), zentrale Ruhemassendichte ρ_c und Randbedingung. ε ist gesamte Energiedichte in J/m³, P Druck in Pa, m(r) Gravitationsmasse in kg, ν dimensionslos. Die Zeitmetrik ist g00 = exp(2ν), der radiale Metrikfaktor (1−2Gm/(rc²))⁻¹.

**Gleichungen in SI:**

```
dm/dr = 4πr² ε/c²
ν' = G(m + 4πr³P/c²) / [c²r²(1−2Gm/(rc²))]
dP/dr = −(ε+P) ν'
```

Am Zentrum m(0)=0; bei kleiner Startstrecke r0: m ≈ 4πr0³ε_c/(3c²). Integriere bis P=0 bzw. bis zur dokumentierten kleinen NS-Oberflächendichte. Setze R als Oberflächenradius, M=m(R). Normiere ν(R)=½ ln(1−2GM/(Rc²)); außerhalb ν(r)=½ ln(1−2GM/(rc²)). Innen niemals die äußere Schwarzschildformel mit m(r) als Ersatz für ν verwenden.

## 5.2 Numerische Skalierung im neuen Code
Um 60 kpc und 12 km mit demselben Solver zu behandeln, nutze x=r/L, M0=4πρ_c L³, u=m/M0, A=GM0/(Lc²), p=P/(ρ_c c²), e=ε/(ρ_c c²). Für EOS-Terme (Γ_i,b_i) gilt s=ρ/ρ_c, p=Σ b_i s^Γ_i und e=s+Σ b_i s^Γ_i/(Γ_i−1). Mit d=min(Γ_i−1), y=s^d wird die Oberfläche regulär; w ist das unnormierte ν/A.

```
du/dx = x² e
w' = (u + x³p) / [x(x−2Au)]
dy/dx = −A (e+p)/(dp/dy) · w'
ν = ν(R) + A[w(x)−w(R)]
```

Der Code kürzt den Quotienten analytisch, sodass er bei y=0 endlich ist. SciPy solve_ivp integriert bis zum Oberflächenereignis. Ein Horizont, fehlendes Ereignis oder ungültige EOS führt zum Abbruch. G wird hier als Eingabe verwendet, nicht aus der Metrik unabhängig hergeleitet. Der Druckgradient erfüllt die statische TOV-Erhaltungsbedingung für die vorgegebene perfekte Flüssigkeit; dies ist kein Erhaltungsbeweis für ein Ising-Archivfeld.

## 5.3 Historischer Solverstatus
`prepare_data.py` im ursprünglichen 3D-ZIP importiert einen externen, nicht mitgelieferten `gr_quellenreferenz.py`. Der neue Kern `code/ciq.py` rekonstruiert dessen dokumentierte Referenzphysik aus den Eingaben. Er ist nicht die wiedergefundene Originaldatei. Die historische JSON wird nur nach der Vorwärtsrechnung verglichen.

<!-- page -->
# 6. Galaktische TOV-Metrik und optischer Weg
## 6.1 Eingaben und Rekonstruktion [H/S/T]
Historische Referenz: kugelförmige, druckgestützte polytrope Flüssigkeit mit Newton-Massenskala M_N = 3 × 10¹¹ Sonnenmassen und Newton-Radius R_N = 60 kpc. Aus dem dokumentierten n=1-Polytropenlimit werden die Eingaben rekonstruiert: ρ_c = π M_N/(4R_N³); K_poly = 2G R_N²/π; P=K_poly ρ²; ε=ρc²+P. Diese Formeln folgen aus der Newtonschen Lane-Emden-Lösung ρ(r)=ρ_c sin(πr/R_N)/(πr/R_N), nicht aus einem Fit an die TOV-Ausgabe. Die so berechneten ρ_c und P_c/(ρ_c c²) stimmen mit den historischen Eingaben überein.

ρ_c ≈ 7,38286271 × 10⁻²³ kg/m³; K_poly ≈ 1,45642940 × 10³² m⁵/(kg s²); P_c/(ρ_c c²) ≈ 1,19639014 × 10⁻⁷. Der neue TOV-Kern ergibt M ≈ 2,99999671 × 10¹¹ Sonnenmassen, R ≈ 59,999980 kpc, Kompaktheit ≈ 4,78556 × 10⁻⁷. M_N und R_N sind Eingabeskalen, nicht exakt die relativistischen Ausgaben.

## 6.2 Drei Observablen aus derselben Metrik
Statische Frequenzverschiebung K_grav(A→B)=exp[ν(B)−ν(A)]. Bei r_A=8 kpc und r_B=60 kpc: K=1,0000002323419608; für die 18,71-µm-Referenz Δλ≈0,00434712 nm. Keine echte Galaxien-Spektralmessung.

Schwache statische GR, Φ≈Ψ≈c²ν, geradliniger Referenzstrahl, Stoßparameter b, endliche Weggrenzen z=±L_half mit L_half=500 kpc. r(z)=√(b²+z²). Optischer Zusatzweg W(b)=−4∫₀ᴸ ν(r(z)) dz. Δt=W/c. Physikalischer Ablenkwinkel α=−dW/db=4∫₀ᴸ ν'(r) b/r dz. W in m, α in rad. Umrechnung in Bogensekunden: α × 180/π × 3600. Der Winkel ist nicht bereits der reduzierte Linsenwinkel einer konkreten Quelle.

Bei b=30 kpc: Δt≈20 039 048 s, α≈0,220583760″. Unabhängige numerische Ableitung mit δb=0,01 kpc: relative Abweichung ≈2,54 × 10⁻⁸. Alle 150 historischen Wegpunkte werden neu erzeugt; maximale relative Abweichung der Ablenkung ≈1,13 × 10⁻⁷. Abweichungen sind numerisch, keine neue Kraft.

**Grenze:** Die 1PN-Wegformel gilt hier wegen kleiner Kompaktheit. Der Code blockiert ihre Verwendung für kompakte NS-Modelle. Für starke Felder müssen Nullgeodäten in der vollständigen Metrik integriert werden. Der endliche Laufzeitzusatz ist referenzabhängig und keine absolute kohärente astronomische Phase. Keine Ising- oder SPARC-Rückkopplung in die TOV-Quelle.

<!-- page -->
# 7. Neutronenstern, Thermik und Entropie
## 7.1 EOS des Originalaudits [H/S/T]
ρ_ref = 2,7 × 10¹⁷ kg/m³; x=ρ_b/ρ_ref; β_cold=0,04. P_cold=β_cold ρ_ref c² x^Γ; P_th=β_th ρ_ref c² x^(5/3). P=P_cold+P_th; ε=ρ_b c²+P_cold/(Γ−1)+P_th/(5/3−1). β_th ist ein vorgegebener thermisch-adiabatischer Testkoeffizient, keine gemessene Entropiedichte. Γ und β_th definieren unterschiedliche EOS, keine zeitliche Entwicklung eines Sterns.

Der neue Solver verwendet dieselbe EOS mit ρ_c als Skalierung und dieselbe Oberflächendichte 10⁻⁷ρ_ref. Er scannt 60 logarithmisch verteilte zentrale Dichteverhältnisse 0,4–35 und verfeinert das erste lokale Massenmaximum. Das Maximum markiert im betrachteten Modell näherungsweise den ersten Stabilitätswechsel, keine Horizontbildung. Der endliche Oberflächen-Cutoff ist eine numerische Näherung.

**Neu berechnete Maxima (M in Sonnenmassen, R in km):**

```
Γ       β_th      M_max      R
2,2     0         1,823972   10,95390
2,4     0         2,064641   11,29959
2,5     0         2,177830   11,49596
2,6     0         2,286255   11,68985
2,7     0         2,390061   11,89476
2,5     0,004     2,192519   11,75996
2,5     0,009     2,212231   12,10648
2,5     0,018     2,251544   12,78137
```

Alle acht stimmen mit den historischen Werten innerhalb 0,002 Sonnenmassen und 0,03 km überein. Am jeweiligen Maximum prüft der Code die Kompaktheit und die Schallgeschwindigkeit auf 201 Dichtewerten. c_s²/c² = dP/dε. Das ist keine Kausalitätsvalidierung aller Modelle des Scans. Für Γ=2,5 steigt die Maximalmasse hier um ca. 0,0737 Sonnenmassen (3,38 %); nicht universell.

## 7.2 Horizontentropie getrennt halten
r_s=2GM/c²; A=4πr_s²; S_BH=k_B A/(4ℓ_P²). Für einen hypothetischen Schwarzschildhorizont derselben Masse gilt S_BH/(4πr_s³/3)=3k_B/(4ℓ_P²r_s). Das ist formale Horizontentropie pro Vergleichsvolumen, kein lokaler thermischer Druck und keine Kollapsschwelle eines Sterns. Die CSV enthält S_BH als Vergleichsgröße, nicht eine NS-Entropiemessung. Keine Rotation, Neutrinos, reale Kern-EOS, dynamische Kollaps- oder starke Linsenrechnung in diesem Modell.

<!-- page -->
# 8. Hubble, SPARC und Ising-Memory
## 8.1 Kosmologische Referenz [S/T]
H0=67,4 km/(s Mpc); Ω_m=0,315; Ω_r=0,000092; Ω_Λ=1−Ω_m−Ω_r. Flaches ΛCDM: R_H=c/H0; ρ_crit=3H0²/(8πG); M_MS=4πρ_crit R_H³/3. Dann 2GM_MS/(R_H c²)=1 und a_H=GM_MS/R_H²=cH0/2. Das ist eine Misner-Sharp-Identität der Gesamtenergiedichte, keine Schwarzschild-BH-Aussage und keine unabhängige Bestimmung von G.

R_particle/R_H=∫₀¹ da/√(Ω_r+Ω_m a+Ω_Λ a⁴). Ergebnis R_H=14,5073 Gly; R_particle=46,1333 Gly; Verhältnis=3,18000324. a_H=3,2741612 × 10⁻¹⁰ m/s²; a_H/π=1,0421979 × 10⁻¹⁰; Ω_m a_H=1,0313608 × 10⁻¹⁰; c²/(2R_particle)=1,0296094 × 10⁻¹⁰. Für separat vorgegebenen R_obs=46,5 Gly: c²/(2R_obs)=1,0214892 × 10⁻¹⁰. Ω_m R_particle/R_H≈1,001701 ist parametersatzabhängig; Einstein-de-Sitter ergibt Verhältnis 2. MOND a0=1,2 × 10⁻¹⁰ ist eine externe empirische Vergleichsskala. Keine dynamische MOND-Herleitung. Hubble-Radius, Teilchenhorizont und Ereignishorizont unterscheiden.

## 8.2 SPARC [E/T]
175 Galaxien, 3389 auswertbare Zeilen (3391 ursprüngliche ROTMOD-Zeilen laut Audit). Datenspalten: r_kpc, v_obs, v_bar, v_RAR in km/s, g_bar, g_obs in m/s², χ=g_bar/a0, v_obs/v_bar. v_bar stammt aus vorgegebenen baryonischen Referenzen mit Υ_disk=0,5 und Υ_bulge=0,7. Rechne g=v²/r in SI. Beispiel DDO154, r=0,49 kpc: g_bar≈5,93629 × 10⁻¹², g_obs≈1,25954 × 10⁻¹¹ m/s². Historisch waren beide g-Spalten auf 0 gerundet; nur diese Spalten wurden rekonstruiert. Die RAR-Kurve ist ein empirisches Modell, keine zweite unabhängige Beobachtung. Keine neue Anpassung oder Gravitation aus SPARC.

## 8.3 Ising-Cross v3 [H/T]
Originale Offline-HTML öffnen. Periodisches 2D-Gitter, Spins s_i=±1, J=1. Metropolis-Flip: ΔE=2s_i(Σ J_ij s_j+h+λ a_i); in COUPLED zusätzlich κ mittlere Magnetisierung. Akzeptanz min(1, exp(−ΔE/T)), T in J/k_B-Einheiten. Archiv a_i ← clip[(1−γ)(a_i+α s_i),−1,1]. XY-Phase: θ_i ← θ_i+dt[DΣ sin(θ_j−θ_i)+γ_XY s_i] modulo 2π. Standard Seed 42, N=32 im Kern; T=2,269, α=0,05, γ=0,01, λ=0,30. Das sind Toy-Parameter. η=0: keine Ising-Wirkung auf IR/GR. η>0: frei gesetzte Phasenstörung, kein Feldgesetz. SPARC bleibt read-only. Historische Tests: `python legacy_tests.py`.

<!-- page -->
# 9. Prüfprotokoll, Fehler und Weiterarbeit
## 9.1 Was tatsächlich neu ausgeführt wurde
49/49 neue Prüfungen (vollständiger Standardlauf); 37/37 im Schnelllauf. Zehn historische Programme separat mit Exitcode 0; darunter 81/81 Cross- und 248/248 Transfer-Assertions. Die 150 TOV-Wege, acht NS-Maxima und 3389 SPARC-Zeilen sind mit dem neuen Kern berechnet. Prüfungen sind gruppierte numerische/technische Tests, keine unabhängigen Experimente. Ergebnisse und Logs im Ordner `ergebnisse/`. Der historische NS-Code ist als Option enthalten, wurde hier nicht separat erneut gestartet. Kein erneuter React-Build und kein Browser-Automationstest.

## 9.2 Stop-Regeln für jede neue Rechnung
- Keine Vakuumreferenz oder keine sichere Linienidentifikation: K nicht als physikalisch eindeutige Verschiebung ausgeben.
- K_total ohne getrennte Ursachen: kein G, keine eindeutige Dopplergeschwindigkeit oder Zeitdilatation behaupten.
- Keine unabhängige Masse: höchstens GM aus zulässiger Schwarzschild-Inversion. Keine G-Herleitung aus G-definierten Planck-Einheiten.
- Phasenalias, Rangverlust, unbekannte Tiefe: keine erfundene 3D-Position. Ein thermisches Spektrum liefert nicht automatisch absolute Phase.
- Keine EOS oder keine Randbedingung: keine TOV-Masse oder Metrik berechnen. Keine Innenraum-Schwarzschild-Abkürzung. Keine schwache 1PN-Linsenformel am kompakten Stern.
- Keine geschlossene Ising-Energiebilanz: keine gravitative Ising-Quelle, keine neue Kopplung oder zusätzliche Lensing-Vorhersage behaupten.

## 9.3 Historische Korrekturen bleiben erhalten
Die Originalarchive werden unverändert mitgeliefert. `daten/HISTORIE_FEHLER_UND_KORREKTUREN.md` dokumentiert u.a. Spiegelmehrdeutigkeit, falsche SPARC-Rundung, fehlende Tiefeninformation, konforme Metrik ohne zusätzliche Lichtablenkung und falsche universelle Zuordnung D=7/4 zur Ising-Spinclusterhülle. Die 10-µm-Referenz ist keine physikalische Analog-Digital-Grenze. Historische Fehler werden nicht nachträglich als Erfolge umgedeutet.

## 9.4 Offener physikalischer Schritt [O]
Für Ising-Spins, Archivfeld und Wärmebad muss eine vollständige Wirkung oder Energiebilanz mit Einheiten und einem kovarianten Energie-Impuls-Tensor definiert werden. Prüfe ∇_μ T^μν=0 und leite daraus eine Metrik ab. Erst dann dürfen Rotation, Lensing und Phasen einer konkreten Galaxie gemeinsam ohne nachträgliche Anpassung verglichen werden. Die TOV-Referenz liefert dafür eine Nullhypothese, nicht die fehlende Kopplung.

**Quellen:** `QUELLENREGISTER.md` nennt die konkreten Originaldateien und abgeleiteten Daten. `verify.py` prüft SHA-256 und ZIP-Integrität. Für neue Arbeit Eingaben, Annahmen, Unsicherheiten, tatsächliche Ausführung und Ergebnisstatus getrennt protokollieren.
