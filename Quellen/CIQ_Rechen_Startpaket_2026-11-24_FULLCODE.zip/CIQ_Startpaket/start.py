#!/usr/bin/env python3
"""CIQ Rechenstart: python start.py [--input DATEI] [--out ORDNER] [--quick]."""
import argparse,csv,json,sys,platform
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from ciq import *
import scipy

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def csvout(p,rows):
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--input',type=Path,default=ROOT/'beispiele/eingaben.json');ap.add_argument('--out',type=Path,default=ROOT/'ergebnisse');ap.add_argument('--quick',action='store_true');a=ap.parse_args();out=a.out;out.mkdir(parents=True,exist_ok=True)
    cfg=read(a.input);default=cfg==read(ROOT/'beispiele/eingaben.json');assert cfg['schema']==1
    checks=[]
    def check(name,ok,detail=None):
        checks.append(dict(name=name,passed=bool(ok),detail=detail));print(('PASS' if ok else 'FAIL')+' '+name,flush=True)
    def close(x,y,rtol=1e-8,atol=0):return abs(x-y)<=atol+rtol*abs(y)
    def rejects(f):
        try:f();return False
        except ValueError:return True
    ref=spectrum(10e-6);A=spectrum(cfg['ir']['lambda_A_um']*1e-6);B=spectrum(cfg['ir']['lambda_B_um']*1e-6);k=K_ir(A['lambda_m'],B['lambda_m'])
    spec=[dict(name=n,**spectrum(l)) for n,l in [('Radio',.1),('H21',.211),('Mikro',.001),('Fern-IR',100e-6),('IR-Anker',10e-6),('Optisch',550e-9),('UV',121.6e-9),('Roentgen',1e-9),('Gamma',1e-12)]];csvout(out/'spektralskala.csv',spec)
    check('10 um: f exakt in SI',close(ref['f_Hz'],29979245800000,1e-15));check('Spektralskala: c und N',all(close(s['lambda_m']*s['f_Hz'],C) and close(s['N'],s['N_time']) for s in spec));check('IR-Operator alle Quotienten',all(close(k,v) for v in [A['f_Hz']/B['f_Hz'],B['T_s']/A['T_s'],A['E_J']/B['E_J'],B['N']/A['N']]))
    check('G-Rueckrechnung (definitorisch)',close(C**3*LP**2/HB,G));check('G x4: c und K invariant, N halbiert',close(2*LP/(2*TP),C) and close((B['lambda_m']/(2*LP))/(A['lambda_m']/(2*LP)),k) and close(A['N']/2,A['lambda_m']/(2*LP)))
    check('Doppler-Inversion',close(beta_from_K(doppler(cfg['ir']['beta'])),cfg['ir']['beta'],atol=1e-14));check('Doppler reziprok',close(doppler(.6)*doppler(-.6),1))
    theta=math.radians(30);Q=np.array([[math.cos(2*theta),math.sin(2*theta)],[math.sin(2*theta),-math.cos(2*theta)]]);u=np.array([math.cos(theta),math.sin(theta)])
    check('Doppelwinkel-Tensor',np.allclose(Q,2*np.outer(u,u)-np.eye(2)));check('Quadratur',close(math.sin(theta)**2+math.cos(theta)**2,1))
    s=cfg['schwarzschild'];rs=2*G*s['mass_kg']/C**2;kg=grav_K(rs,s['r_A_m'],s['r_B_m']);rs2=invert_rs(kg,s['r_A_m'],s['r_B_m']);check('Schwarzschild synthetische Inversion',close(rs2,rs));check('gleiche Radien blockiert',rejects(lambda:invert_rs(1,10,10)));check('Horizont blockiert',rejects(lambda:grav_K(10,10,20)))
    ph=cfg['phase'];lam=ph['lambda_obs_um_synthetic']*1e-6;base=ph['baseline_um']*1e-6;Bmat=np.eye(3)*base;n=unit(ph['azimuth_deg'],ph['polar_from_z_deg']);phases=wrap(Bmat@n*2*np.pi/lam);lower=.9*lam;depth=None if ph['depth_kpc'] is None else ph['depth_kpc']*KPC
    rec=phase_invert(Bmat,phases,lambda_min=lower,depth=depth);rec['K']=rec['lambda_m']/(ph['lambda_rest_um']*1e-6)
    check('3D Phase Richtung und Wellenlaenge',np.allclose(rec['direction'],n) and close(rec['lambda_m'],lam));check('planare Basen blockiert',rejects(lambda:phase_invert(np.diag([base,base,0]),phases,lambda_min=lower)));check('lange Basen blockiert',rejects(lambda:phase_invert(np.eye(3)*lam,phases,lambda_min=lower)));check('unbekannte Tiefe bleibt null',phase_invert(Bmat,phases,lambda_min=lower)['source_position_m'] is None);check('fehlende Wellenlaengen-Untergrenze blockiert',rejects(lambda:phase_invert(Bmat,phases)))
    rng=np.random.default_rng(ph['seed']);errors=[];ks=[]
    for _ in range(ph['noise_samples']):
        r=phase_invert(Bmat,phases+rng.normal(0,ph['noise_sigma_rad'],3),lambda_min=lower);errors.append(np.degrees(np.arccos(np.clip(np.dot(n,r['direction']),-1,1))));ks.append(r['lambda_m']/(ph['lambda_rest_um']*1e-6))
    rec.update(phases_rad=phases.tolist(),noise_median_deg=float(np.median(errors)),noise_p95_deg=float(np.quantile(errors,.95)),K_noise_median=float(np.median(ks)))
    if default:check('1200 Rauschtests: P95 < 0.2 Grad',rec['noise_p95_deg']<.2)
    h=cfg['halo'];halo,hin=halo_model(h);halo2,_=halo_model(h,rtol=2e-11,max_step=.005);hs=halo.summary();hs.update(hin);hs['K_grav']=halo.K(h['r_A_kpc']*KPC,h['r_B_kpc']*KPC);hs['shift_nm']=(hs['K_grav']-1)*h['line_um']*1000
    check('Halo TOV Schrittverfeinerung',close(halo.M,halo2.M,1e-7) and close(halo.R,halo2.R,1e-7));check('Halo Oberflaechenmetrik',close(halo.nuR,.5*math.log1p(-halo.compact)));check('Halo Druck positiv, Masse monoton',all(halo.state(x*halo.R)[1]>=0 for x in np.linspace(0,.99,20)) and np.all(np.diff([halo.state(x*halo.R)[0] for x in np.linspace(0,1,100)])>=0));check('Halo statische Rotverschiebung nach aussen',halo.K(halo.R/2,halo.R)>1)
    L=h['half_path_kpc']*KPC;rays=[dict(b_kpc=b,**halo.ray(b*KPC,L)) for b in range(1,151)];csvout(out/'halo_wege.csv',rays);ray30=rays[29];db=.01*KPC;fd=-(halo.ray(30*KPC+db,L)['W_m']-halo.ray(30*KPC-db,L)['W_m'])/(2*db);hs['ray_30kpc']=ray30;hs['gradient_relative_error']=abs(fd/ray30['alpha_rad']-1);check('Halo Weggradient vs direkte Ablenkung',hs['gradient_relative_error']<1e-5,hs['gradient_relative_error'])
    if default:
        old=read(ROOT/'daten/gr_tov_path_reference.json');oldh=read(ROOT/'daten/TOV_REFERENZ_HISTORISCH.json');oldir=read(ROOT/'daten/TOV_IR_LENSING_HISTORISCH.json');diffs=[abs(r['alpha_rad']/o['alpha_rad']-1) for r,o in zip(rays,old['rays'])];dd=[abs(r['delay_s']/o['delay_s']-1) for r,o in zip(rays,old['rays'])];hs['historical_max_relative_alpha']=max(diffs);hs['historical_max_relative_delay']=max(dd)
        check('Halo historische Masse und Radius',close(halo.M/MSUN,oldh['gravitational_mass_Msun'],1e-6) and close(halo.R/KPC,oldh['radius_kpc'],1e-6));check('Halo historische 150 Wege',max(diffs)<2e-5 and max(dd)<2e-5,[max(diffs),max(dd)]);check('Halo historische Rotverschiebung (K-1)',close(hs['K_grav']-1,oldir['redshift']['K_IR_GR']-1,2e-5))
    radial=[]
    for x in np.linspace(0,1,201):
        r=x*halo.R;m,p,e,nu=halo.state(r);radial.append(dict(r_kpc=r/KPC,m_solar=m/MSUN,P_Pa=p,epsilon_J_m3=e,nu=nu,g00=math.exp(2*nu)))
    csvout(out/'halo_radial.csv',radial)
    nc=cfg['ns'];cases=[(nc['gamma_cold'],0),(nc['gamma_cold'],nc['beta_thermal'][-1])] if a.quick else list(dict.fromkeys([(g,0) for g in nc['gamma_scan']]+[(nc['gamma_cold'],b) for b in nc['beta_thermal']]))
    nsrows=[]
    for g,b in cases:
        print(f'NS Scan Gamma={g}, beta_th={b}',flush=True);row,model=ns_maximum(nc,g,b);row['radius_km']=row['radius_m']/1000;row['rs_km']=2*G*model.M/C**2/1000;row['K_surface_to_infinity']=math.exp(-model.nuR);row['S_BH_comparison_J_K']=KB*math.pi*(2*G*model.M/C**2)**2/LP**2;nsrows.append(row)
        check(f'NS Gamma={g} beta={b}: Kompaktheit und lokale Schallgeschwindigkeit am Maximum',model.compact<1 and all(0<=model.sound2(y)<1 for y in np.linspace(0,1,201)))
        if g==nc['gamma_cold'] and b==0:
            finer=ns_model(nc,row['central_density_ratio'],g,b,rtol=3e-9,max_step=.004);check('NS Schrittverfeinerung',abs(finer.M-model.M)/MSUN<.002 and abs(finer.R-model.R)<30);check('NS 1PN-Lensing blockiert',rejects(lambda:model.ray(model.R,10*model.R)))
        if default:
            hist=read(ROOT/'daten/ns_resultate_historisch.json');hr=next(x for x in hist['models_eos']+hist['models_thermal'] if x['gamma']==g and x['beta_thermal']==b);check(f'NS historische Referenz Gamma={g} beta={b}',abs(row['mass_solar']-hr['mass_solar'])<.002 and abs(row['radius_km']-hr['radius_km'])<.03)
    csvout(out/'ns_maxima.csv',nsrows)
    co=cosmology(cfg['cosmology']);check('FLRW Misner-Sharp Kompaktheit',close(co['compactness'],1));check('Einstein-de-Sitter Gegenprobe',close(cosmology({**cfg['cosmology'],'Omega_m':1,'Omega_r':0})['ratio_particle_H'],2));co['parameter_sweep']=[dict(Omega_m=m,ratio=cosmology({**cfg['cosmology'],'Omega_m':m,'Omega_r':0 if m==1 else cfg['cosmology']['Omega_r']})['ratio_particle_H']) for m in [.2,.315,.5,1]]
    orig=read(ROOT/'daten/sparc_raw_reference_ORIGINAL_2026_11_11.json');corr=read(ROOT/'daten/sparc_raw_reference_corrected.json');rows=[];other_ok=True;zero=0;maxdiff=0;chi=0
    for go,gc in zip(orig,corr):
        other_ok &= go['name']==gc['name'] and len(go['points'])==len(gc['points'])
        for p,q in zip(go['points'],gc['points']):
            r,vo,vb,vr=p[:4];gb=vb**2*1e6/(r*KPC);gobs=vo**2*1e6/(r*KPC);zero+=p[4]==p[5]==0;other_ok &= p[:4]==q[:4] and p[6:]==q[6:];maxdiff=max(maxdiff,abs(gb/q[4]-1),abs(gobs/q[5]-1) if q[5] else abs(gobs));chi=max(chi,abs(gb/1.2e-10-p[6]));rows.append(dict(galaxy=go['name'],r_kpc=r,vobs_km_s=vo,vbar_km_s=vb,vrar_km_s=vr,gbar_m_s2=gb,gobs_m_s2=gobs))
    csvout(out/'sparc_recomputed.csv',rows);check('SPARC 175 Galaxien / 3389 Zeilen',len(orig)==len(corr)==175 and len(rows)==3389);check('SPARC nur Beschleunigungsspalten korrigiert',other_ok and zero==3389 and maxdiff<1e-12);check('SPARC chi Rundungsgrenze',chi<3e-5)
    result=dict(scope='Rechenreferenz, keine unabhaengige empirische Bestaetigung',versions=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__),default_input=default,quick=a.quick,inputs=cfg,constants=dict(c=C,h=H,G=G,lP=LP,tP=TP),IR=dict(reference=ref,K=k,doppler_K=doppler(cfg['ir']['beta']),G_reconstructed_synthetic=C*C*rs2/(2*s['mass_kg']),rs_m=rs2,grav_K=kg),phase=rec,halo=hs,ns=nsrows,cosmology=co,sparc=dict(galaxies=len(orig),rows=len(rows),original_zero_fields=zero,max_chi_difference=chi),checks=checks,passed=sum(x['passed'] for x in checks),total=len(checks))
    (out/'pruefergebnisse.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8');print(f"{result['passed']}/{result['total']} PASS; {out}");return 0 if result['passed']==result['total'] else 1
if __name__=='__main__':sys.exit(main())
