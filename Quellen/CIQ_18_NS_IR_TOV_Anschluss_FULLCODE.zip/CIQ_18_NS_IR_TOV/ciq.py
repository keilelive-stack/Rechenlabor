"""CIQ: eigenstaendige Referenzrechnung. SI, ausser explizit benannte Einheiten.
Keine CIQ-Parameteranpassung. Neue Rekonstruktion, nicht historischer Originalsolver.
"""
import math
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import minimize_scalar
C=299792458.0; H=6.62607015e-34; HB=H/(2*math.pi); G=6.67430e-11
MSUN=1.98847e30; KPC=3.085677581491367e19; LY=C*31557600; EV=1.602176634e-19; KB=1.380649e-23
LP=math.sqrt(HB*G/C**3); TP=LP/C

def positive(*args):
    if not all(math.isfinite(x) and x>0 for x in args): raise ValueError('Positive endliche Eingaben erforderlich')

def spectrum(lam):
    positive(lam); f=C/lam; T=lam/C
    return dict(lambda_m=lam,f_Hz=f,T_s=T,E_J=H*f,E_eV=H*f/EV,N=lam/LP,N_time=T/TP)

def K_ir(a,b):
    positive(a,b); return b/a

def doppler(beta):
    if not abs(beta)<1: raise ValueError('|beta| muss <1 sein')
    return math.sqrt((1+beta)/(1-beta))

def beta_from_K(k):
    positive(k); return (k*k-1)/(k*k+1)

def grav_K(rs,a,b):
    positive(a,b)
    if not 0<=rs<min(a,b): raise ValueError('Nur statische Beobachter ausserhalb des Horizonts')
    return math.sqrt((1-rs/b)/(1-rs/a))

def invert_rs(k,a,b):
    positive(k,a,b)
    if a==b: raise ValueError('Gleiche Radien: keine Inversion')
    den=k*k/a-1/b
    if den==0: raise ValueError('Singulaere Inversion')
    rs=(k-1)*(k+1)/den
    if not 0<=rs<min(a,b): raise ValueError('K und Radien nicht mit positiver Schwarzschildmasse vereinbar')
    return rs

def unit(az,polar):
    a,t=np.deg2rad([az,polar]); return np.array([np.sin(t)*np.cos(a),np.sin(t)*np.sin(a),np.cos(t)])

def wrap(p): return (np.asarray(p)+np.pi)%(2*np.pi)-np.pi

def phase_invert(B,p,lambda_min=None,unwrapped=False,depth=None):
    B=np.asarray(B,float); p=np.asarray(p,float)
    if B.shape!=(3,3) or p.shape!=(3,) or not np.isfinite(B).all() or not np.isfinite(p).all(): raise ValueError('3x3 Basenmatrix und 3 Phasen erforderlich')
    if np.linalg.matrix_rank(B)!=3 or np.linalg.cond(B)>1e8: raise ValueError('Rangverlust oder schlecht konditionierte Basen')
    if not unwrapped:
        if lambda_min is None: raise ValueError('Unabhaengige Untergrenze der Wellenlaenge oder entfaltete Phasen erforderlich')
        positive(lambda_min)
        if np.max(np.linalg.norm(B,axis=1))>=lambda_min/2: raise ValueError('2pi-Alias nicht ausgeschlossen')
        if np.max(np.abs(p))>=np.pi: raise ValueError('Phase ausserhalb des eindeutigen Zweigs')
    k=np.linalg.solve(B,p); norm=np.linalg.norm(k); positive(norm)
    n=k/norm; lam=2*np.pi/norm
    if not unwrapped and lam<lambda_min*(1-1e-12): raise ValueError('Rekonstruierte Wellenlaenge unter unabhaengiger Untergrenze')
    if depth is not None: positive(depth)
    return dict(k_rad_m=k.tolist(),lambda_m=float(lam),direction=n.tolist(),source_direction=(-n).tolist(),azimuth_deg=float(np.degrees(np.arctan2(n[1],n[0]))%360),polar_deg=float(np.degrees(np.arccos(np.clip(n[2],-1,1)))),source_position_m=None if depth is None else (-n*depth).tolist())

class TOV:
    """Gemeinsamer dimensionsloser TOV-Kern fuer kalte/thermische Polytropen.
    x=r/L, u=m/(4*pi*rho_c*L^3), p=P/(rho_c*c^2), e=eps/(rho_c*c^2).
    y=(rho/rho_c)^(gamma_min-1) regularisiert die Oberflaeche.
    """
    def __init__(self,rho_c,L,terms,surface_fraction=0,xmax=10,rtol=2e-9,max_step=.02):
        positive(rho_c,L); self.L=L; self.rho_c=rho_c
        if not terms or any(g<=1 or b<=0 for g,b in terms): raise ValueError('EOS: gamma>1, beta>0')
        if not 0<=surface_fraction<1: raise ValueError('Oberflaechenanteil')
        self.terms=terms; self.d=min(g-1 for g,b in terms); self.M0=4*np.pi*rho_c*L**3; self.A=G*self.M0/(L*C*C)
        d=self.d; A=self.A
        def eos(y):
            y=max(float(y),0.0); s=y**(1/d)
            p=sum(b*s**g for g,b in terms); e=s+sum(b*s**g/(g-1) for g,b in terms)
            # (e+p)/(dp/dy), analytisch gekuerzt, auch bei y=0 definiert
            ratio=d*(1+sum(g*b/(g-1)*y**((g-1)/d) for g,b in terms))/sum(g*b*y**((g-1)/d-1) for g,b in terms)
            return p,e,ratio
        self.eos=eos
        def rhs(x,v):
            u,y,w=v; p,e,ratio=eos(y); den=x*(x-2*A*u)
            if den<=0: raise ValueError('Horizont im TOV-Integrationsbereich')
            vprime=(u+x**3*p)/den # dnu/dx / A
            return [x*x*e,-A*ratio*vprime,vprime]
        def surface(x,v): return v[1]-surface_fraction**d
        surface.terminal=True; surface.direction=-1
        x0=1e-7; e0=eos(1)[1]
        sol=solve_ivp(rhs,(x0,xmax),[e0*x0**3/3,1,0],events=surface,dense_output=True,rtol=rtol,atol=[rtol*.01]*3,max_step=max_step)
        if not sol.success or not len(sol.t_events[0]): raise ValueError('Keine Oberflaeche erreicht')
        self.sol=sol; self.x0=x0; self.xR=float(sol.t_events[0][0]); self.uR,_,self.wR=sol.y_events[0][0]
        self.R=self.xR*L; self.M=self.uR*self.M0; self.compact=2*G*self.M/(C*C*self.R)
        self.nuR=.5*math.log1p(-self.compact)
    def state(self,r):
        if r<0: raise ValueError('r>=0')
        if r>=self.R: return self.M,0.,0.,.5*math.log1p(-2*G*self.M/(C*C*r))
        u,y,w=self.sol.sol(max(r/self.L,self.x0)); p,e,_=self.eos(y)
        m=float(u*self.M0) if r>=self.x0*self.L else 4*np.pi*r**3*self.rho_c*self.eos(1)[1]/3
        return m,p*self.rho_c*C*C,e*self.rho_c*C*C,self.nuR+self.A*(w-self.wR)
    def nu(self,r): return self.state(r)[3]
    def nuprime(self,r):
        if r==0:return 0.
        m,p,_,_=self.state(r); return G*(m+4*np.pi*r**3*p/C**2)/(C**2*r*r*(1-2*G*m/(C*C*r)))
    def K(self,a,b): return math.exp(self.nu(b)-self.nu(a))
    def sound2(self,y):
        s=max(y,0)**(1/self.d)
        return sum(g*b*s**(g-1) for g,b in self.terms)/(1+sum(g*b/(g-1)*s**(g-1) for g,b in self.terms))
    def summary(self):
        return dict(mass_solar=self.M/MSUN,radius_m=self.R,compactness=self.compact,central_sound_over_c=math.sqrt(self.sound2(1)))
    def ray(self,b,Lhalf):
        positive(b,Lhalf)
        if self.compact>1e-4: raise ValueError('1PN geradliniger Strahl nur fuer schwache Referenz; keine NS-Linsenrechnung')
        def path(f):
            edge=math.sqrt(max(self.R**2-b*b,0)); cuts=[edge/Lhalf] if 0<edge<Lhalf else None
            return Lhalf*quad(lambda t:f(t*Lhalf),0,1,points=cuts,epsabs=1e-30,epsrel=2e-8,limit=150)[0]
        W=-4*path(lambda z:self.nu(math.hypot(b,z)))
        alpha=4*path(lambda z:self.nuprime(math.hypot(b,z))*b/math.hypot(b,z))
        return dict(W_m=W,delay_s=W/C,alpha_rad=alpha,alpha_arcsec=alpha*180/np.pi*3600)

def halo_model(cfg,rtol=2e-9,max_step=.02):
    M=cfg['mass_scale_solar']*MSUN; R=cfg['newton_radius_kpc']*KPC; positive(M,R)
    rho=np.pi*M/(4*R**3); pol=2*G*R**2/np.pi; beta=pol*rho/C**2
    return TOV(rho,R,[(2.,beta)],rtol=rtol,max_step=max_step),dict(rho_c_kg_m3=rho,K_SI=pol,beta=beta)

def ns_model(cfg,ratio,gamma=None,beta_th=0,rtol=2e-7,max_step=.012):
    gamma=cfg['gamma_cold'] if gamma is None else gamma; rho=cfg['rho_ref_kg_m3']*ratio
    if beta_th<0:raise ValueError('beta_th >=0')
    terms=[(gamma,cfg['beta_cold']*ratio**(gamma-1))]
    if beta_th>0: terms.append((5/3,beta_th*ratio**(2/3)))
    return TOV(rho,10000,terms,cfg['surface_density_ratio']/ratio,10,rtol,max_step)

def ns_maximum(cfg,gamma,beta_th):
    vals=np.geomspace(cfg['scan_min'],cfg['scan_max'],cfg['scan_points'])
    masses=np.array([ns_model(cfg,x,gamma,beta_th).M/MSUN for x in vals])
    maxima=np.where((masses[1:-1]>masses[:-2])&(masses[1:-1]>masses[2:]))[0]+1
    if not len(maxima): raise ValueError('Kein inneres Massenmaximum im Scan')
    i=maxima[0]; opt=minimize_scalar(lambda q:-ns_model(cfg,math.exp(q),gamma,beta_th).M/MSUN,bounds=(math.log(vals[i-1]),math.log(vals[i+1])),method='bounded',options={'xatol':1e-7})
    if not opt.success: raise ValueError('Maximum nicht gefunden')
    x=math.exp(opt.x); model=ns_model(cfg,x,gamma,beta_th)
    return dict(gamma=gamma,beta_thermal=beta_th,central_density_ratio=x,**model.summary()),model

def cosmology(cfg):
    H0=cfg['H0_km_s_Mpc']*1000/(1000*KPC); om=cfg['Omega_m']; orad=cfg['Omega_r']; ol=1-om-orad
    positive(H0,cfg['R_obs_Gly'],cfg['a0_m_s2'])
    if not 0<om<=1 or orad<0 or ol<0: raise ValueError('Nur flache LCDM-Referenz mit nichtnegativen Dichten')
    RH=C/H0; rho=3*H0**2/(8*np.pi*G); mass=4*np.pi*rho*RH**3/3
    ratio=quad(lambda a:1/math.sqrt(orad+om*a+ol*a**4),0,1,epsrel=1e-10)[0]
    return dict(H0_s_inv=H0,R_H_Gly=RH/(1e9*LY),rho_crit_kg_m3=rho,M_MS_kg=mass,compactness=2*G*mass/(RH*C*C),a_H=C*H0/2,a_H_over_pi=C*H0/(2*np.pi),a_m=om*C*H0/2,R_particle_Gly=RH*ratio/(1e9*LY),ratio_particle_H=ratio,Omega_m_times_ratio=om*ratio,a_particle=C*C/(2*RH*ratio),a_obs=C*C/(2*cfg['R_obs_Gly']*1e9*LY),q0=om/2+orad-ol)
