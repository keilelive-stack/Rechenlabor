import csv,json,math
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import quad
import ciq
P=Path(__file__).resolve().parent
cfg=json.loads((P/'eingaben.json').read_text())['ns']
old=json.loads((P/'historisch.json').read_text())
new=json.loads((P/'CIQ_NS_Massengrenze_TOV_Entropie_Audit/resultate.json').read_text())
assert old==new
f0=ciq.C/1e-5
rows=[]; checks=[]
def check(n, ok, value):
 checks.append(dict(test=n,passed=bool(ok),value=value)); assert ok,(n,value)
def compute(g,b,x,kind,ref=None):
 m=ciq.ns_model(cfg,x,g,b,rtol=3e-9,max_step=.004)
 R=m.R; M=m.M; C=m.compact; rs=C*R
 K=1/math.sqrt(1-C); Kc=math.exp(-m.nu(0)); Kcs=m.K(0,R)
 h=lambda q:1+g/(g-1)*cfg['beta_cold']*q**(g-1)+(5/2)*b*q**(2/3)
 enth=h(x)/h(cfg['surface_density_ratio'])
 # independent geometry integral for the center-to-surface lapse
 integ=quad(m.nuprime,0,R,epsabs=1e-10,epsrel=1e-9,limit=300)[0]
 check('TOV enthalpy vs lapse '+kind,abs(Kcs/enth-1)<1e-7,Kcs/enth-1)
 check('TOV lapse gradient '+kind,abs(math.log(Kcs)-integ)<1e-7,math.log(Kcs)-integ)
 check('IR composition '+kind,abs(Kc/(Kcs*K)-1)<1e-12,Kc/(Kcs*K)-1)
 check('external Schwarzschild inversion '+kind,abs(ciq.invert_rs(m.K(R,2*R),R,2*R)/rs-1)<1e-12,ciq.invert_rs(m.K(R,2*R),R,2*R)/rs-1)
 check('causality and no horizon '+kind,0<m.sound2(1)<1 and C<1,[m.sound2(1),C])
 # synthetic phase array recovers shifted surface line (no real observation)
 B=np.eye(3)*3e-6; k=2*np.pi/(1e-5*K)*ciq.unit(32,40); p=B@k
 inv=ciq.phase_invert(B,p,lambda_min=1e-5)
 check('3D wavelength recovery '+kind,abs(inv['lambda_m']/(1e-5*K)-1)<1e-12,inv['lambda_m']/(1e-5*K)-1)
 # external acceleration for stationary observer; formal BH entropy only hypothetical horizon
 acc=ciq.G*M/R**2*K
 d=dict(case=kind,gamma=g,beta_th=b,rho_c_ratio=x,M_solar=M/ciq.MSUN,R_km=R/1000,rs_km=rs/1000,C=C,K_surface_inf=K,z_surface=K-1,lambda_surface_um=10*K,f_surface_THz=f0/K/1e12,T_surface_fs=1e-5*K/ciq.C*1e15,lapse_surface=1/K,K_center_surface=Kcs,K_center_inf=Kc,lambda_center_formal_um=10*Kc,f_center_formal_THz=f0/Kc/1e12,lapse_center=1/Kc,hc_over_hs=enth,surface_proper_g_m_s2=acc,cs_center_over_c=math.sqrt(m.sound2(1)),BH_entropy_comparison_over_kB=math.pi*(rs/ciq.LP)**2)
 if ref:
  check('independent mass '+kind,abs(d['M_solar']-ref['mass_solar'])<2e-5,d['M_solar']-ref['mass_solar'])
  check('independent radius '+kind,abs(d['R_km']-ref['radius_km'])<.001,d['R_km']-ref['radius_km'])
 rows.append(d);return d
for r in new['models_eos']:
 compute(r['gamma'],r['beta_thermal'],r['central_density_ratio'],'max_cold',r)
for r in new['models_thermal']:
 compute(r['gamma'],r['beta_thermal'],r['central_density_ratio'],'max_thermal',r)
for r in new['models_thermal']:
 b=r['beta_thermal']; x=brentq(lambda q:ciq.ns_model(cfg,q,2.5,b).M/ciq.MSUN-1.4,.4,r['central_density_ratio'],xtol=1e-10)
 d=compute(2.5,b,x,'fixed_1.4M'); check('fixed mass',abs(d['M_solar']-1.4)<2e-5,d['M_solar']-1.4)
with (P/'IR_TOV_Anschluss.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
(P/'Anschluss_Resultate.json').write_text(json.dumps({'checks':checks,'models':rows,'passed':sum(x['passed'] for x in checks)},indent=2))
for r in rows: print(r['case'],r['gamma'],r['beta_th'],*[round(r[k],8) for k in ['M_solar','R_km','C','K_surface_inf','lambda_surface_um','K_center_surface','K_center_inf','f_surface_THz']])
print('CHECKS',len(checks),sum(x['passed'] for x in checks))
