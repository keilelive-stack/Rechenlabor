#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CIQ: TOV-Massengrenzen, mikroskopischer Materiedruck und thermischer Beitrag.

Reproduzierbares RECHENMODELL, kein realer EOS-Fit und keine dynamische GR-Kollapssimulation.
Benötigt numpy scipy matplotlib. Ausführung: python run_audit.py
"""
from pathlib import Path
import csv
import json
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar
import matplotlib.pyplot as plt

G = 6.67430e-11                         # m^3 kg^-1 s^-2
C = 299792458.0                        # m/s
M_SUN = 1.98847e30                     # kg
M_SUN_GEOM_KM = G*M_SUN/C**2/1000.0    # km, G=c=1
RHO_REF = 2.7e17                       # kg/m3, typische Kernsaettigungsdichte
RHO_REF_GEOM = G*RHO_REF/C**2 * 1e6    # km^-2
GAMMA_TH = 5.0/3.0


def thermodynamics(log_rho, gamma, beta_cold, beta_thermal):
    """p, eps, d p/d log(rho), d eps/d log(rho), alle in km^-2.

    p_cold = beta_cold rho_ref c² (rho/rho_ref)^Gamma.
    p_th = beta_thermal rho_ref c² (rho/rho_ref)^(5/3).
    eps = rho c² + p_cold/(Gamma-1) + p_th/(Gamma_th-1).
    """
    x = np.exp(np.clip(log_rho, -40, 12))
    rho = RHO_REF_GEOM*x
    p_c = RHO_REF_GEOM*beta_cold*x**gamma
    p_t = RHO_REF_GEOM*beta_thermal*x**GAMMA_TH
    p = p_c+p_t
    eps = rho+p_c/(gamma-1)+p_t/(GAMMA_TH-1)
    dpdq = gamma*p_c+GAMMA_TH*p_t
    depsdq = rho+gamma*p_c/(gamma-1)+GAMMA_TH*p_t/(GAMMA_TH-1)
    return p,eps,dpdq,depsdq


def stellar_model(rho_center_factor, gamma=2.5, beta_cold=0.04,
                  beta_thermal=0.0, max_step=0.12, rtol=2e-7):
    """Integriert TOV bis zur fest gewaehlten sehr niedrigen Oberflaechendichte.

    Geometrisierte Gleichungen: dm/dr=4 pi r² eps,
    dp/dr=-(eps+p)(m+4 pi r³ p)/(r(r-2m)),
    wobei r,m in km und eps,p in km^-2.
    """
    q0=np.log(rho_center_factor)
    p0,e0,_,_=thermodynamics(q0,gamma,beta_cold,beta_thermal)
    r0=1e-4   # km
    m0=4*np.pi*r0**3*e0/3
    q_surface=np.log(1e-7)

    def rhs(r, y):
        m,q=y
        p,eps,dpdq,_=thermodynamics(q,gamma,beta_cold,beta_thermal)
        den=r*(r-2*m)
        if den <= 0:
            raise ValueError('Numerischer Horizont erreicht, keine TOV-Sternloesung')
        grav=-(eps+p)*(m+4*np.pi*r**3*p)/den
        return [4*np.pi*r*r*eps, grav/dpdq]

    def surface(r,y):
        return y[1]-q_surface
    surface.terminal=True
    surface.direction=-1
    sol=solve_ivp(rhs,(r0,100),[m0,q0],events=surface,
                  rtol=rtol,atol=[1e-9,1e-10],max_step=max_step)
    if not len(sol.t_events[0]):
        raise ValueError('Keine Oberflaeche erreicht')
    R=float(sol.t_events[0][0])
    mg=float(sol.y_events[0][0][0])
    mass=mg/M_SUN_GEOM_KM
    p,eps,dpdq,depsdq=thermodynamics(q0,gamma,beta_cold,beta_thermal)
    compactness=2*mg/R
    sound_speed_squared=dpdq/depsdq
    return dict(central_density_ratio=float(rho_center_factor),
                mass_solar=float(mass),radius_km=R,
                schwarzschild_radius_km=2*mg,
                compactness=float(compactness),
                central_sound_speed_over_c=float(np.sqrt(sound_speed_squared)))


def sequence(gamma=2.5,beta_cold=.04,beta_thermal=0.,N=60):
    vals=np.geomspace(.4,35,N)
    data=[stellar_model(x,gamma,beta_cold,beta_thermal) for x in vals]
    ix=int(np.argmax([d['mass_solar'] for d in data]))
    lo=np.log(vals[max(0,ix-1)])
    hi=np.log(vals[min(N-1,ix+1)])
    res=minimize_scalar(lambda xx: -stellar_model(np.exp(xx),gamma,beta_cold,beta_thermal)['mass_solar'],
                        bounds=(lo,hi),method='bounded',options={'xatol':1e-7})
    best=stellar_model(np.exp(res.x),gamma,beta_cold,beta_thermal)
    return data,best


def write_csv(path,rows):
    with path.open('w',encoding='utf-8',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]))
        wr.writeheader();wr.writerows(rows)


def main():
    folder=Path(__file__).resolve().parent
    rows_eos=[]; eos_curves={}
    for g in (2.2,2.4,2.5,2.6,2.7):
        seq,peak=sequence(gamma=g)
        peak['gamma']=g;peak['beta_cold']=0.04;peak['beta_thermal']=0.0
        rows_eos.append(peak)
        eos_curves[g]=seq
    rows_thermal=[]; thermal_curves={}
    for bt in (0.0,.004,.009,.018):
        seq,peak=sequence(gamma=2.5,beta_thermal=bt)
        peak['gamma']=2.5;peak['beta_cold']=.04;peak['beta_thermal']=bt
        rows_thermal.append(peak)
        thermal_curves[bt]=seq
    write_csv(folder/'massengrenzen_eos.csv',rows_eos)
    write_csv(folder/'massengrenzen_thermisch.csv',rows_thermal)
    write_csv(folder/'referenz_tov_kurve.csv',eos_curves[2.5])

    fig,ax=plt.subplots(figsize=(9,6))
    for g,seq in eos_curves.items():
        ax.plot([x['radius_km'] for x in seq],[x['mass_solar'] for x in seq],
                label=f'Γ={g:g}')
    for r in rows_eos:
        ax.plot(r['radius_km'],r['mass_solar'],'o',markersize=4)
    ax.set(xlabel='Sternradius R [km]',ylabel='Gravitationsmasse M [Sonnenmassen]',
           title='Relativistisches TOV-Modell: Masse-Radius-Kurven verschiedener Kernmaterie')
    ax.grid(alpha=.2);ax.legend()
    fig.tight_layout();fig.savefig(folder/'01_eos_masse_radius.png',dpi=190);plt.close(fig)

    fig,ax=plt.subplots(figsize=(9,6))
    for b,seq in thermal_curves.items():
        ax.plot([x['radius_km'] for x in seq],[x['mass_solar'] for x in seq],
                label=f'Thermischer Druckkoeffizient β_th={b:g}')
    for r in rows_thermal:
        ax.plot(r['radius_km'],r['mass_solar'],'o',markersize=4)
    ax.set(xlabel='Sternradius R [km]',ylabel='Gravitationsmasse M [Sonnenmassen]',
           title='Separater thermischer Druckanteil: Verschiebung der Massengrenze')
    ax.grid(alpha=.2);ax.legend()
    fig.tight_layout();fig.savefig(folder/'02_thermischer_druck.png',dpi=190);plt.close(fig)

    ref=eos_curves[2.5]
    fig,ax=plt.subplots(figsize=(9,6))
    ax.plot([x['central_density_ratio'] for x in ref],[x['mass_solar'] for x in ref])
    mx=rows_eos[2]
    ax.axvline(mx['central_density_ratio'],linestyle='--',color='grey',
               label=f'Max. stabile Masse bei ρc/ρ0≈{mx["central_density_ratio"]:.2f}')
    ax.set_xscale('log')
    ax.set(xlabel='Zentrale Ruhemassendichte relativ zu 2,7×10¹⁷ kg/m³',
           ylabel='Gravitationsmasse M [Sonnenmassen]',
           title='TOV-Umkehrpunkt: Zentrale Dichte steigt, Masse fällt danach')
    ax.grid(alpha=.2);ax.legend()
    fig.tight_layout();fig.savefig(folder/'03_tov_umkehrpunkt.png',dpi=190);plt.close(fig)

    res={'constants':{'G':G,'c':C,'solar_mass_kg':M_SUN,'rho_ref_kg_m3':RHO_REF},
         'equations':'TOV + polytrope p_cold=K rho^Gamma; p_th=K_th rho^(5/3)',
         'models_eos':rows_eos,'models_thermal':rows_thermal,
         'interpretation':'Toy-model results, not observed maximum masses or evidence for CIQ.'}
    (folder/'resultate.json').write_text(json.dumps(res,indent=2,ensure_ascii=False),encoding='utf-8')
    print('EOS:')
    for r in rows_eos:
        print('Gamma',r['gamma'],'Mmax',round(r['mass_solar'],4),'R km',round(r['radius_km'],3),
              'C',round(r['compactness'],3),'cs/c',round(r['central_sound_speed_over_c'],3))
    print('Thermischer Zusatz:')
    for r in rows_thermal:
        print('beta_th',r['beta_thermal'],'Mmax',round(r['mass_solar'],4),'R km',round(r['radius_km'],3))

    # Reproduzierbarkeit: zweite Integrationsgenauigkeit und kleinerer Integrationsschritt.
    x=rows_eos[2]['central_density_ratio']
    a=stellar_model(x,2.5,.04,0.,max_step=.12,rtol=2e-7)
    b=stellar_model(x,2.5,.04,0.,max_step=.04,rtol=3e-9)
    assert abs(a['mass_solar']-b['mass_solar']) < 2e-3, (a,b)
    assert abs(a['radius_km']-b['radius_km']) < .03, (a,b)
    assert all(r['compactness']<1 for r in rows_eos)
    assert all(r['central_sound_speed_over_c']<1 for r in rows_eos)
    print('Kontrollen: Refinement und Kausalitaet bei den Maximalmodellen bestanden.')

if __name__=='__main__':main()
