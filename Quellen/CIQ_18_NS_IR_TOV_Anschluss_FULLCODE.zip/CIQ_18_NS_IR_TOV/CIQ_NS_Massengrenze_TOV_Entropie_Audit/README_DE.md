# CIQ – Neutronensterne: variable maximale Masse und entropischer Druck

**Stand 26. Oktober 2026 – nachgerechnetes relativistisches TOV-Testmodell, keine reale EOS-Kalibrierung und keine zeitabhängige Kollapssimulation.**

## Forschungsfrage
Warum tragen manche Neutronensterne deutlich mehr Masse, bevor sie ihre Stabilität verlieren? Reicht Gravitation/Dichte allein, oder beeinflussen Entropie und Wärme die Grenze? Vergleich zum CIQ-Entropieschutzschalter.

## 1. Annahmen und Gleichungen

Tolman–Oppenheimer–Volkoff für einen statischen, isotropen und **nicht rotierenden** Stern:

- `dm/dr = 4 π r² ε / c²`
- `dP/dr = -(G/(c² r²)) (ε+P) (m+4πr³P/c²)/(1-2Gm/(r c²))`

Hier ist `ε` die gesamte Energiedichte in J/m³ (Ruheenergie plus innere Energie); `P` ist Druck in Pa. Für die numerische Integration benutzen wir G=c=1, `r,m` in km und `P, ε` in km⁻².

Test-Zustandsgleichung:

- `P_cold = β_cold ρ_ref c² (ρ_b/ρ_ref)^Γ`, `ρ_ref=2.7e17 kg/m³`, `β_cold=0.04`.
- `P_th = β_th ρ_ref c² (ρ_b/ρ_ref)^(5/3)`.
- `ε = ρ_b c² + P_cold/(Γ−1) + P_th/(5/3−1)`.

Die zweite Komponente ist eine konsistente *adiabatische ideale thermische Testkomponente*: Für jede feste `β_th` ist ein bestimmter thermischer Entropiezustand impliziert. `β_th` ist **keine gemessene Entropiedichte und kein allgemeiner physikalischer Entropieparameter**; realistische Neutronensternmaterie erfordert eine kernphysikalisch kalibrierte EOS `P(ρ,T,Y_e,...)`.

Die zentrale Ruhemassendichte `ρ_c` wird variiert. Die TOV-Gleichung wird vom Zentrum bis zu einer kleinen Oberflächendichte `1e−7 ρ_ref` integriert. Anschließend wird die maximale Masse durch lokale Verfeinerung bestimmt.

Für **eine unveränderte kalte EOS** wird der erste Massen-Umkehrpunkt `dM/dρ_c = 0` näherungsweise als Beginn der fundamentalen radialen Instabilität interpretiert. Dieser Umkehrpunkt liegt bei R>Rs; es ist nicht der Zeitpunkt einer schon vorhandenen Horizontbildung.

## 2. Ergebnisse: Drucksteifigkeit, kalte Modellfamilie

| Γ | M_max [M_Sonne] | Radius [km] | R_s [km] | 2GM/(Rc²) | ρ_c / ρ_ref | c_s,zentral/c |
|---:|---:|---:|---:|---:|---:|---:|
| 2.2 | 1.824 | 10.956 | 5.386 | 0.492 | 7.10 | 0.723 |
| 2.4 | 2.065 | 11.300 | 6.098 | 0.540 | 6.27 | 0.813 |
| 2.5 | 2.178 | 11.497 | 6.432 | 0.559 | 5.90 | 0.856 |
| 2.6 | 2.286 | 11.698 | 6.752 | 0.577 | 5.57 | 0.898 |
| 2.7 | 2.390 | 11.902 | 7.059 | 0.593 | 5.27 | 0.938 |

Alle maximalen Modelle im Scan haben zentrale Schallgeschwindigkeit < c; einige stark komprimierte Modelle weit **hinter** dem Umkehrpunkt können weitere Unphysikalitäten aufweisen. Es wurde keine durchgehende mikroskopische Kausalitätsprüfung für sämtliche Punkte als physikalische Validierung ausgegeben. Sehr weiche vollständige EOS, die keine pulsarbeobachteten ca. 2 M_Sonne tragen, sind ausgeschlossen.

## 3. Ergebnisse: zusätzliche thermische Druckkomponente bei Γ=2.5

| β_th | M_max [M_Sonne] | Radius [km] |
|---:|---:|---:|
| 0 | 2.178 | 11.497 |
| 0.004 | 2.193 | 11.760 |
| 0.009 | 2.212 | 12.106 |
| 0.018 | 2.252 | 12.781 |

In diesem Beispiel **erhöht** die thermal-adiabatische Komponente die maximal tragbare Masse um ca. 0.074 Sonnenmassen (3.4%) zwischen β_th=0 und 0.018. Die allgemeine Wirkung von Temperatur, Leptonen, Quark- und Hyperonenanteilen ist EOS-abhängig; eine größere Entropie kann nicht stets als zusätzlicher stabilisierender Druck angesetzt werden.

## 4. Bedeutung für den CIQ-Schutzschalter

- Die BH-Schwelle ist **nicht** ein universeller Zahlenwert für die Materiemasse und erst recht nicht ein bestimmter Entropiedichtewert.
- Der physikalische NS-Kipppunkt folgt aus der **gemeinsamen EOS und der TOV-Dynamik**. Bei konstanter EOS zeigt er sich im ersten Maximum der Masse als Funktion der zentralen Dichte.
- Entropie kann den Kipppunkt beeinflussen, **indem sie den thermischen Anteil der EOS verändert**; sie ist keine zusätzliche frei verfügbare Energiequelle.
- Die Bekenstein-Hawking-Entropie `S_BH=k_B A/(4l_P²)` ist eine Horizontgröße nach Bildung eines BH und kann nicht vorab als thermischer Innendruck eingesetzt werden.
- Die in älteren CIQ-Dokumenten verwendete Skalierung `s*_BH(R)=3k_B/(4 l_P² R)` ist die geometrische **formale Horizontentropie je Vergleichs-Kugelvolumen**, keine thermische lokale Kollapsschwelle.
- Ein hypothetischer zusätzlicher CIQ-Feldbeitrag muss als eigene gekoppelte Feld-Energie und eigener Druck in einer physikalisch geschlossenen Zustandsgleichung/Energie-Impuls-Bilanz implementiert werden.

## 5. Rotation (außerhalb dieses TOV-Rechenprogramms)

Gleichförmige schnelle Rotation kann realistischen Modellen zufolge etwa 20% mehr maximale Masse ermöglichen, gelegentlich bis ~25%. Dies ist eine **Literaturinformation und kein numerisch ausgeführter Rotationstest**. Beispiel: 2.178 M_Sonne * 1.20 = 2.61 M_Sonne (nur Illustration). Magnetfelder, differentielle Rotation, Neutrinotransport und Entropieproduktion sind hier nicht gelöst.

## 6. Validierung und technische Grenzen

- Der TOV-Integrationstest wird mit deutlich kleinerem Schritt und engerer Toleranz wiederholt (max. ΔM < 0.002 M_Sonne und ΔR < 0.03 km am Referenzmaximum).
- Kompaktheit `2GM/(Rc²)<1` und zentraler Schall `c_s<c` wurden an allen ermittelten Maxima geprüft.
- Beim Variieren einer EOS (Γ oder β_th) vergleicht man **verschiedene Materiemodelle**, nicht die historische Evolution eines einzelnen konkreten Sterns.
- Die Massen sind Gravitationsmassen, nicht identisch mit der gesamten baryonischen Ruhemasse.
- Radiuswerte hängen vom gewählten effektiven Modell und dem Oberflächen-Abbruchwert ab; keine crust-geeichte realistische Masse-Radius-Anpassung.

## 7. Ausführung

`python run_audit.py`

Erzeugt drei Abbildungen `01_...png` bis `03_...png`, detaillierte Tabellen `massengrenzen_*.csv`, eine `referenz_tov_kurve.csv` und `resultate.json`.

## Quellen zu den externen Aussagen

- NICER-Messung J0740+6620: https://doi.org/10.3847/1538-4357/ad5f1f
- TOV/EOS-Überblick: https://doi.org/10.1007/s41114-024-00049-6
- Rotation: https://pmc.ncbi.nlm.nih.gov/articles/PMC6036631/
- Thermal/Lepton-Effekte: https://www.sciencedirect.com/science/article/pii/S0550321324002633
- Thermal-Effekt kann je nach EOS auch destabilisieren: https://arxiv.org/abs/2509.23910

**Status:** Reproduzierbare Modellrechnung. Keine Bestätigung eines zusätzlichen entropiegetriebenen CIQ-Schwarzschild-Schutzschalters.
