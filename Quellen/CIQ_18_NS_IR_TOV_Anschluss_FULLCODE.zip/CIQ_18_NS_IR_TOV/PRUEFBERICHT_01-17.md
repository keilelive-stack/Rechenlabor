# CIQ – Abarbeitung des nummerierten Operator-Archivs

**Quelle:** Operator_sortiert_nummeriert.zip, 17 Etappen, 34 Originaldateien.  
**Methode:** nummerierte Reihenfolge ist bindend; Original-ZIP unverändert; Programme aus separaten entpackten Arbeitskopien ausgeführt. Kein Fit an historische Zielwerte und keine Änderung des IR-Operators. GitHub wurde lesend verwendet: https://github.com/keilelive-stack/Physik (öffentlich, main; vorhandene CIQ-Atlas- und Simulationsquellen). Kein Upload, Commit oder Änderung am Repository; das Archiv ist die Rechenreferenz.

## Ergebnisse in Reihenfolge

| Etappe | Quelleninhalt | Neu ausgeführter Befund | Physikalischer Status |
|---|---|---|---|
| 01 | IR-Referenz, Planck, Beobachter, Lichttensor | 14+24+25 = 63/63 | c lokal invariant; Nullstrahl-Tensor ist keine gelöste eigene Metrik |
| 02 | Spektrallinien / c / G / Phase | 17/17 | G-Rückrechnung aus G-abhängigen Planckgrößen zirkulär |
| 03 | gemeinsamer IR-Operator | 62/62 | Achromatisches Verhältnismaß; Doppelwinkel keine Dynamik |
| 04 | Herleitung c und G | 94/94 | K=1.0075793166668918; G=6.674300000000108e-11 aus synthetischer GR-Eingabe |
| 05 | 310 K, Oberfläche und Dichte | 102/102 | Wien-Maximum 9.347651 µm, Brutto 523.670985 W/m², netto zu 300 K 64.370657 W/m²; keine Sondergrenze bei 310 K |
| 06 | Vereinigung bei 0 K | 2 zusätzliche Dokument-Kontrollen | Vorzeichen des Selbstenergieterms entscheidet über die Diskriminante, keine allgemeine Planck-Grenze daraus |
| 07 | Test Vereinigung | 1 zusätzliche Dokument-Kontrolle | uΛ/uP=1.223053137889e-123 für H0=70 und ΩΛ=0.685; eingesetzte kosmologische Eingaben |
| 08 | Lösung: FLRW-Dynamik | 3 zusätzliche Dokument-Kontrollen | a*=0.612627746; z*=0.632312618; q0=−0.5275. Konstantes u_g/H² bei separater Materieerhaltung verhält sich wie Staub, nicht wie dunkle Energie |
| 09 | Gesamtarchiv und Grenztests | 34/34 | vier eingebettete Quellenmanifeste 60/60; 0-K-, FLRW- und Regge-Grenzen bleiben erhalten |
| 10 | Photon–Gravitation Gegenaudit | 13/13 | bei fester Richtung und Energie hebt die magnetische Komponente die Polarisationsabhängigkeit des elektrischen Quadrupols im vollständigen EM-Tensor auf |
| 11 | Vier Stufen: Hadron/Torsion/Spin | 3 zusätzliche Dokument-Kontrollen | A=48.955 MeV; Qxz=23.570226 MeV; 8Qxz=188.561808 MeV; kein unabhängiger J-Nachweis |
| 12 | Mehrbeobachter/Phasen | 49/49 | Kges=1.0587746062 synthetisch, rekonstruiert 1.0587744359; Entfernung benötigt Zusatzinformation |
| 13 | Ising-Phasen/Baryogenese/IR | 89/89; 12 Sensitivitätsvarianten | subkritische Hysterese stärker; Baryogenese/XY/IR-Kopplungen sind Toymodelle |
| 14 | MOND Explorer | 87/87; 11 Bessel-Stützstellen; 10 Browser-Kontrollen | max. rel. Bessel-Abweichung 0.000182329; a0 Eingabe, keine MOND-Herleitung |
| 15 | 54-Seiten-Gegenaudit | 22/22; Monte-Carlo-Referenzlauf | falsche Dimension/konformes Lensing/fehlende Dynamik dokumentiert; alte Fits und Hausdorff-Analyse nicht reproduzierbar, Quellcode fehlt |
| 16 | SPARC / Dritter Pol | 10/10 + 8/8 | 175 Galaxien, 3391 Originalzeilen, 3389 gültig; 361 negative Gasgeschwindigkeiten mit Vorzeichen berücksichtigt; normiertes ODE-Spielzeugmodell, keine neue Magnetladung |
| 17 | gemeinsames Cross-Labor | 81/81; 150 Diagnosezeilen; Browser PASS | Ising-Memory und XY geteilter Zustand; SPARC read-only; η=0 Nullkopplung; Speicherfehler s.u. |

## Zahlenbilanz

22/22 ausgewählte dokumentierte Python-/Node-/Browser-Programme liefen mit Exitcode 0. Summe der explizit nummerierten internen Tests in den obigen 13 ZIP-Etappen: 731/731 (ohne zusätzliche Browser-, Bessel-, Sensitivitäts-, Monte-Carlo- und Dokumentkontrollen). Neun neu ergänzte Rechenkontrollen in den vier PDF-Etappen 06/07/08/11 bestanden. Die Summe ist keine Zahl unabhängiger empirischer Nachweise; mehrere Tests überlappen. 13/13 enthaltene Haupt-ZIPs und das äußere ZIP bestehen CRC-Prüfung. 293/293 Dateiverweise in den unmittelbar enthaltenen erkannten SHA-256-Manifesten sind gültig. Das Archiv 09 enthält zusätzlich einen eigenen 60/60 Manifest-Audit über eingebettete Quellen; nicht addieren. In 24 vorhandenen Ergebnis-JSON-Paaren sind 23 byteidentisch, ein Browser-Protokoll aus 14 enthält den aktuellen lokalen Pfad. Diese Paarzählung umfasst auch nicht neu erzeugte Archivdateien; maßgeblich für den Rechenlauf sind die Laufprotokolle.

## Konkreter historischer Speicherfehler in 17

`ising-suite/src/data/sparc_raw_reference.json`: alle 3389 Einträge enthalten gBar=0 und gObs=0. Die übrigen Spalten r, vObs, vBar, vRAR, χ und vObs/vBar bleiben vorhanden. Rekonstruktion: g=(1000 v[km/s])²/(r[kpc] × 3.085677581491367e19 m/kpc). Vergleich von gBar/a0 mit χ: maximale relative Abweichung 2.77e-5, konsistent mit den gerundeten gespeicherten χ-Werten. Kein Datenverlust der Geschwindigkeiten. Fehler im Original nicht überschrieben. Der spätere, hier nicht enthaltene 3D-Transfer-Audit ist als historische Anschlussstufe bekannt, aber nicht Teil dieses Laufs.

## Rechenvertrag für Fortsetzung

1. Quelle A und Empfänger B sowie Vakuumwellenlängen und Einheiten vorab festlegen. K_IR=λB/λA=fA/fB=TB/TA=NB/NA. 10 µm bleiben Referenz, nicht eine automatisch physikalisch privilegierte Wellenlänge.
2. c=λf=ℓP/tP; N=λ/ℓP=T/tP. G aus Planck-Einheiten nur als Rückrechnung kennzeichnen. Bei statischen Schwarzschild-Beobachtern r_s=(K²−1)/(K²/rA−1/rB); G=c²r_s/(2M) setzt unabhängige Massen- und Geometrieinformation voraus.
3. Doppler, gravitative und kosmologische Faktoren nur unter deklarierter Messgeometrie kombinieren. Einzelnes K identifiziert die Ursachen nicht. Kohärente Phasenmessung erfordert entfaltete Phasen und Messbasen.
4. Für SPARC Rohgeschwindigkeiten/Einheiten erhalten; M/L=0.5/0.7 und a0=1.2e-10 m/s² als vorgegebene Referenzen kennzeichnen, nicht als Vorhersage. Rotationsdaten nicht in Ising-Zustandsentwicklung zurückfüttern.
5. Ising→XY und η getrennt von physikalischen GR-Gleichungen halten. Eine erhaltene Quelle Tμν und eine Metrik aus einer festgelegten Wirkung sind noch zu bestimmen; konforme Zusatzmetrik allein liefert keine zusätzliche Lichtablenkung.

## Umfangsgrenzen

Keine Änderung der Originalprogramme, keine Neuimplementierung fehlender Originalfit-Codes. React/npm-Produktionsbuilds, optionale Plot-/Report-/Installer-Programme und Browser-Test der Etappe 13 wurden nicht separat ausgeführt. Die 34 äußeren Dateien wurden inventarisiert, die vorhandenen Begleitdokumente als Text extrahiert und die zentralen Rechenbefunde zugeordnet; dies ist keine vollständige visuelle Seitendurchsicht aller in verschachtelten ZIPs enthaltenen historischen PDFs. Das Archiv endet bei Etappe 17 und enthält nicht das spätere 3D-Transfer-/TOV-Upgrade. Die in 06–08/11 neu ausgeführten Kontrollen sind eigenständige algebraische Nachrechnungen, keine dort enthaltenen Originalskripte.

## Paketstruktur

- `Laufprotokolle`: Originalausgaben und Exitcodes je Programm.
- `Pruefregister.json`: SHA-256-Inventar, Manifestprüfungen, JSON-Vergleich, Dokument-Kontrollen und SPARC-Speicherbefund.
- `Rechenergebnisse`: Ergebnis-JSON/CSV aus den Arbeitskopien, einschließlich vorhandener unveränderter Begleitresultate.
- `Dokumenttext`: textbasierte Extraktion der äußeren PDF-/DOCX-/MD-Begleitdateien (kein Ersatz für Originale, Formeln können durch PDF-Extraktion unvollständig sein).

